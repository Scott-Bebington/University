class Main {
    public static void main(String[] args) {
        FTPListner ftplistner = new FTPListner();
        ftplistner.listen();
    }
}
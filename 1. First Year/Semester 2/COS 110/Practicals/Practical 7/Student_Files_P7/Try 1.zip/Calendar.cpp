#ifndef CALENDAR_CPP
#define CALENDAR_CPP

#include "Calendar.h"

using namespace std;

Calendar::Calendar()
{
    head = NULL;
    cout << "Blank Calendar Created" << endl;
}

Calendar::Calendar(vector<event_data> input)
{
    head = NULL;
    for (int i = 0; i < input.size(); i++)
    {
        createEvent(input[i]);
    }
}

Calendar::~Calendar()
{
    clearCalendar();
}

Event *Calendar::getUpcomingEvent(long int now)
{
    int count = 0;
    Event* nodePtr = head;
    Event* returnvalue;
    long int tempstart = nodePtr->start;;
    while (nodePtr->next != NULL)
    {
        if (tempstart > now && count == 0)
        {
            count ++;
            returnvalue = nodePtr;
        }
        nodePtr = nodePtr->next;
        tempstart = nodePtr->start;
        if (tempstart > now && tempstart < returnvalue->start)
        {
            returnvalue = nodePtr;
        }
    }
    return returnvalue;
}

vector<Event> Calendar::filterEvents(int *id, long int *start, long int *end, string *type)
{
    vector<Event> vec;
    Event* nodePtr = head;

    while(nodePtr->next != NULL)
    {
        if (id != NULL && *id == nodePtr->id)
        {
            vec.push_back(*nodePtr);
        }
        else if (start != NULL && nodePtr->start > *start && end != NULL && nodePtr->end < *end)
        {
            vec.push_back(*nodePtr);
        }
        else if(start != NULL && nodePtr->start > *start)
        {
            vec.push_back(*nodePtr);
        }
        else if(end != NULL && nodePtr->end < *end)
        {
            vec.push_back(*nodePtr);
        }
        else if (type != NULL && nodePtr->type == *type)
        {
            vec.push_back(*nodePtr);
        }
        else if(id == NULL && start == NULL && end == NULL && type == NULL)
        {
            vec.push_back(*nodePtr);
        }
    }
    return vec;
}

void Calendar::alterEvent(int id, long int *end, string *type)
{
    Event *nodePtr = head;
    while (nodePtr->next != NULL)
    {
        if (nodePtr->id == id)
        {
            nodePtr->end = *end;
            nodePtr->type = *type;
        }
    }
}

void Calendar::removeEvent(int id)
{
    Event *nodePtr = head;
    Event *previousNode = NULL;

    if (head)
    {
        while (nodePtr && nodePtr->id != id)
        {
            previousNode = nodePtr;
            nodePtr = nodePtr->next;
        }
        if (nodePtr)
        {
            if (nodePtr == head)
            {
                head = head->next;
                delete nodePtr;
            }
            else
            {
                previousNode->next = nodePtr->next;
                delete nodePtr;
            }
        }
    }
}

void Calendar::createEvent(event_data data)
{
    Event *newNode;
    Event *nodePtr;
    Event *previousNode;

    newNode = new Event(data.start, data.end, data.id, data.type);
    newNode->start = data.start;
    newNode->end = data.end;
    newNode->id = data.id;
    newNode->type = data.type;
    newNode->next = NULL;

    if (!head)
    {
        head = newNode;
    }
    else
    {
        nodePtr = head;
        previousNode = NULL;

        while (nodePtr && nodePtr->start < newNode->start)
        {
            previousNode = nodePtr;
            nodePtr = nodePtr->next;
        }
        if (!previousNode)
        {
            head = newNode;
            newNode->next = nodePtr;
        }
        else
        {
            previousNode->next = newNode;
            newNode->next = nodePtr;
        }
    }
}

void Calendar::clearCalendar()
{
    Event *nodePtr = head;
    while (nodePtr)
    {
        head = head->next;
        delete nodePtr;
        nodePtr = head;
    }
}

Event *Calendar::getFirstEvent()
{
    return head;
}

ostream &operator<<(ostream& out, Calendar& calendar)
{
    int count = 0;
    Event* nodePtr = calendar.head;
    out << count << ": " << *nodePtr << endl;

    while (nodePtr->next != NULL)
    {
        count ++;
        nodePtr = nodePtr->next;
        out << count << ": " << *nodePtr << endl;
    }
    return out;
};
#endif

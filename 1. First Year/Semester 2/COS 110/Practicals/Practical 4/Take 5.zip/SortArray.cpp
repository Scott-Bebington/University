#ifndef SORTARRAY_CPP
#define SORTARRAY_CPP

#include "SortArray.h"

using namespace std;

    SortArray::SortArray(int** array, int* sizes, int baseSize) : TwoDArray(array, sizes, baseSize){
    }

    int* SortArray::operator[](int value) // address, send back entire array
    {
        int temp;
        int* tempvalue = &value;
        int* sizes = getSizes();
        int** array = getArray();
        for (int i = 0; i < sizes[*tempvalue]; i++)
        {
            for (int j = 0; j > sizes[*tempvalue]; j++)
            {
                if (array[*tempvalue][j] < array[*tempvalue][i])
                {
                    temp = array[*tempvalue][j];
                    array[*tempvalue][j] = array[*tempvalue][i];
                    array[*tempvalue][i] = temp;
                }
            }
        }
        int* returnarray = array[*tempvalue];
        return returnarray; // return sorted array
    }

#endif
#ifndef TWODARRAY_CPP
#define TWODARRAY_CPP

#include "TwoDArray.h"
#include <iostream>

using namespace std;

TwoDArray::TwoDArray(int** array, int* sizes, int baseSize)
{
    int count = 0;
    this->array = array;
    this->sizes = sizes;
    this->baseSize = baseSize;

    this->array = new int*[this->baseSize];
	this->sizes = new int[this->baseSize];

    for (int i = 0; i < this->baseSize; i++)
	{
		this->sizes[i] = this->baseSize;
		this->array[i] = new int[this->baseSize];

		for (int k = 0 ; k < this->sizes[i]; k++)
		{
			this->array[i][k] = count++;
		}
	}
}

TwoDArray::~TwoDArray()
{
	for (int i = 0; i < baseSize; i++)
	{
		for (int k = 0 ; k < sizes[i]; k++)
		{
			array[i][k] = 0;
		}
	}
}

int** TwoDArray::getArray()
{    
    return array;
}

int* TwoDArray::getSizes()
{
    return sizes;
}

int TwoDArray::getBaseSize()
{
	return baseSize;
}

TwoDArray::operator int()
{
	return getBaseSize();
}

TwoDArray::operator int*()
{
	return getSizes();
}

TwoDArray::operator int**()
{
	return getArray();
}

std::ostream& operator<<(std::ostream& os, TwoDArray& tda)
{
	for (int i = 0; i < tda.baseSize; i++)
	{
		for (int k = 0 ; k < tda.sizes[i]; k++)
		{
			if (k < tda.sizes[i]-1)
			{
				os << tda.array[i][k] << " ";
			}
			else
			{
				os << tda.array[i][k] << endl;
			}
		}
	}
	return os;
}

#endif
#ifndef SORTARRAY_CPP
#define SORTARRAY_CPP

#include "SortArray.h"

using namespace std;

    SortArray::SortArray(int** array, int* sizes, int baseSize) : TwoDArray(array, sizes, baseSize){
    }

    int* SortArray::operator[](int value) // address, send back entire array
    {
        return *this;
    }

#endif
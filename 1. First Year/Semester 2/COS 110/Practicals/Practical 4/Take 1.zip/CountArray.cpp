#ifndef COUNTARRAY_CPP
#define COUNTARRAY_CPP

#include "CountArray.h"

using namespace std;

    CountArray::CountArray(int** array, int* sizes, int baseSize) : TwoDArray(array, sizes, baseSize){
    }

    int* CountArray::operator[](int value)
    {
        int tempcount = 0;
        int *sizes = getSizes();
        for (int i = 0; i < sizes[i]; i++)
        {
            tempcount++;
        }
        int* count = new int(tempcount);
        return count;
    }

#endif
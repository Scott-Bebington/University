#ifndef __RECURSIVESOLUTION_H__
#define __RECURSIVESOLUTION_H__

#include "RecursiveSolution.h"

template <class T>
RecursiveSolution<T>::RecursiveSolution(int startTower, int goalTower)
{
    this->startTower = startTower;
    this->goalTower = goalTower;

    this->t1 = new stack<Disk<T> *>();
    this->t2 = new stack<Disk<T> *>();
    this->t3 = new stack<Disk<T> *>();
}

// template <class T>
void solvegamehelper(int n, int start, int end, int aux)
{
    if (n == 0)
    {
        return;
    }
    solvegamehelper(n - 1, start, aux, end);
    cout << "Move disk from tower " << start << " to tower " << end << endl;
    // TowersOfHanoi<T>::moveDisk(start, end);
    solvegamehelper(n - 1, aux, end, start);
}

template <class T>
void RecursiveSolution<T>::solveGame()
{

    int start = this->startTower;
    int end = this->goalTower;
    int aux = 6 - (start + end);
    int numdisks = count();
    if (!TowersOfHanoi<T>::validateGame())
    {
        solvegamehelper(numdisks, start, end, aux);
        return;
    }
    throw Exception<T>::invalidGame();

}

template <class T>
int RecursiveSolution<T>::count()
{
    int countdisks = 0;
    this->t1 = this->getTower(1);
    this->t2 = this->getTower(2);
    this->t3 = this->getTower(3);
    countdisks = counthelper(this->t1, 0);
    countdisks = counthelper(this->t2, countdisks);
    countdisks = counthelper(this->t3, countdisks);
}
template <class T>
int counthelper(T t, int count)
{
    if (t->empty())
    {
        return count;
    }
    t->pop();
    counthelper(t, count + 1);
}

template <class T>
bool RecursiveSolution<T>::containsLabel(T label)
{
    cout << "Label to be found is: " << label << endl;
    bool flag = false;
    this->t1 = this->getTower(1);
    this->t2 = this->getTower(2);
    this->t3 = this->getTower(3);
    if (containshelp(this->t1, label))
    {
        return true;
    }
    if (containshelp(this->t2, label))
    {
        return true;
    }
    if (containshelp(this->t1, label))
    {
        return true;
    }
    return false;
}

template <class T>
bool containshelp(stack<Disk<T> *> *t, T label)
{
    if (t->empty())
    {
        return false;
    }
    if (t->top()->getLabel() == label)
    {
        return true;
    }
    t->pop();
    containshelp(t, label);
}
#endif // __RECURSIVESOLUTION_H__
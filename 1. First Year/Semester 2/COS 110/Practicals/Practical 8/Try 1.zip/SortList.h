#ifndef DLL_H
#define DLL_H

#include "SortNode.h"
#include "SortList.cpp"

// SortList class Implementation here
template <class T>
class SortList
{
private:
    bool ascending;
    SortNode<T> *head;
    SortNode<T> *tail;

public:
    SortList(bool);
    void add(SortNode<T> *);
    SortNode<T> *remove(T val);
    void sort();
    string print();
    SortNode<T> *getHead();
    void setAsc(bool);
    string debug();
};
template <typename T>
SortList<T>::SortList(bool asc)
{
    head = NULL;
    tail = NULL;
    ascending = asc;
}

template <typename T>
void SortList<T>::add(SortNode<T> *a)
{
    SortNode<T> *newNode;

    newNode = a;
    if (!head) // test whether head is null
    {
        head = newNode; // make the new node the head of the list
        tail = newNode;
    }
    else // insert at the end of the list
    {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
}

template <typename T>
SortNode<T> *SortList<T>::remove(T val)
{
    SortNode<T> *nodePtr = head;
    SortNode<T> *prevNode = NULL;
    SortNode<T> *temp;

    if (head)
    {
        while (nodePtr && nodePtr->getValue() != val)
        {
            prevNode = nodePtr;
            nodePtr = nodePtr->next;
        }
        if (nodePtr)
        {
            if (nodePtr == head)
            {
                head = head->next;
                temp = new SortNode<int>(nodePtr->getValue());
                delete nodePtr;
                return temp;
            }
            else
            {
                prevNode->next = nodePtr->next;
                temp = new SortNode<int>(nodePtr->getValue());
                delete nodePtr;
                return temp;
            }
        }
    }
    else
    {
        return NULL;
    }
}

template <typename T>
void SortList<T>::sort()
{
    SortList<int> *temp = new SortList<int>(1);
    SortNode<T> *nodePtr = head, *nodePtr2 = head, *small, *large = head;
    int count = 0;
    while (nodePtr) // traversing the list
    {
        if (nodePtr->getValue() > large->getValue()) // finding the largest value in the list
        {
            large = nodePtr;
        }
        nodePtr = nodePtr->next;
        count++; // to find out how many links are in the list
    }
    nodePtr = head;
    nodePtr2 = head->next;
    for (int i = 0; i < count; i++)
    {
        nodePtr2 = head;
        small = large;
        while (nodePtr2)
        {
            if (nodePtr2->getValue() < small->getValue())
            {
                small = nodePtr2;
            }
            nodePtr2 = nodePtr2->next;
        }
        temp->add(new SortNode<int>(small->getValue()));
        remove(small->getValue());
    }
    head = temp->head;
    tail = temp->tail;
    if (!ascending)
    {
        SortList<int> *temp2 = new SortList<int>(1);
        nodePtr = tail;
        while (nodePtr) // traversing the list
        {
            temp2->add(new SortNode<int>(nodePtr->getValue()));
            nodePtr = nodePtr->prev;
        }
        head = temp2->head;
        tail = temp2->tail;
    }
}

template <typename T>
string SortList<T>::print()
{
    SortNode<T> *nodePtr;
    string output = "";
    nodePtr = head;
    int count = 0;
    if (head) // test whether head is null
    {
        while (nodePtr->next)
        {
            output += to_string(nodePtr->getValue());
            output += ",";
            nodePtr = nodePtr->next;
        }
        output += to_string(nodePtr->getValue());
    }
    return output;
}

template <typename T>
SortNode<T> *SortList<T>::getHead()
{
    return head;
}

template <typename T>
void SortList<T>::setAsc(bool a)
{
    ascending = a;
    sort();
}

template<class T>
string SortList<T>::debug()
{
    return *this;
}
#include "SortList.cpp"

#endif

#ifndef SN_H
#define SN_H

#include <string>
#include <sstream>
#include <iostream>
#include "SortNode.cpp"

//SortNode class implementation here
template <class T>
class SortNode
{
    protected:
        T value;

    public:
        SortNode<T>* next;
        SortNode<T>* prev;
        SortNode(T);
        string print();
        T getValue();

};
template<class T>
SortNode<T>::SortNode(T val)
{
    value = val;
    next = NULL;
    prev = NULL;
}

template<class T>
string SortNode<T>::print()
{
    return to_string(value);
}

template<class T>
T SortNode<T>::getValue()
{
    return value;
}


#include "SortNode.cpp"

#endif

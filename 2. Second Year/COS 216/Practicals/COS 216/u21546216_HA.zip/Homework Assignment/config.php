<?php
    $host = "localhost";
    $username = "u21546216";
    $password = "ZTG66N4TEDUKVD6LHMUWCUKAPLD7LFXM";
    $database = "u21546216_cars";

    $DBConnection = new mysqli($host, $username, $password, $database);
?>
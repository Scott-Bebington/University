function GoToPage() {
    window.location.href = "./signup.php";
}
How to use: When Visiting the website, you are taken to the Index page which has a list of all the cars on my website, you can then choose to brows through all of the different car pages such as the:
Find Car: this is a more specific car page designed to help you find your perfect car.
Brands: This page displays a list of brands given on the website.
Compare: This page allows the coustomer to compare the specifications of 2 cars of their choosing.
Login: this page allows the user to log into their account using their login details.
Sign Up: this allows a user without an account to create an account with their email address and password.
Logout: once the user is logged in they have the choice to logout of the page if they dont want to stay signed in.
(All functionality has been implimented)

Once logged in, the user can choose between any preferences they like with regards to the filters along with the choice of light or dark mode.

Default login details:
Email:     scottbebington@gmail.com
Password:  Scott12!




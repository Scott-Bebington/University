var searchData=
[
  ['validatetoken_27',['ValidateToken',['../classValidateToken.html#ae64cd2eacd0cc239dabc6367f94958d0',1,'ValidateToken']]]
];

var searchData=
[
  ['makerequest_5',['makeRequest',['../classServer.html#a06e57a2e0ffc807bc81533b6a3457221',1,'Server']]]
];

var searchData=
[
  ['server_8',['Server',['../classServer.html',1,'']]],
  ['signin_9',['SignIn',['../classSignIn.html',1,'SignIn'],['../classSignIn.html#a084c8847b971f545e66187b74d565d84',1,'SignIn::SignIn()']]]
];

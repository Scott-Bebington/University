var searchData=
[
  ['validatetoken_11',['ValidateToken',['../classValidateToken.html',1,'ValidateToken'],['../classValidateToken.html#ae64cd2eacd0cc239dabc6367f94958d0',1,'ValidateToken::ValidateToken()']]]
];

var searchData=
[
  ['datahandler_1',['DataHandler',['../classDataHandler.html',1,'DataHandler'],['../classDataHandler.html#a51d845c1d9bbeef44607ec7592ba3c1d',1,'DataHandler::DataHandler()']]]
];

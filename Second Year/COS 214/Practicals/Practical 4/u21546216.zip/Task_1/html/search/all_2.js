var searchData=
[
  ['generatenonsetoken_2',['generateNonseToken',['../classRequestNonseToken.html#a2707f637386ef17457fe63dde7b42165',1,'RequestNonseToken']]],
  ['getuser_3',['getUser',['../classServer.html#a3487424fa32bf250269bc394eab731af',1,'Server']]]
];

var searchData=
[
  ['datahandler_12',['DataHandler',['../classDataHandler.html',1,'']]]
];

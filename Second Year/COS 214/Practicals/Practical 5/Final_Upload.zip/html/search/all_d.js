var searchData=
[
  ['person_0',['Person',['../class_person.html',1,'']]],
  ['plateorder_1',['plateOrder',['../class_head_chef.html#acec54e7b6909bec957d25efc3dbd1fd6',1,'HeadChef']]],
  ['pragma_20once_20instead_20of_20ifndef_20define_2',['Headers use &apos;#pragma once&apos; instead of &apos;#ifndef...#define&apos;',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['prepare_3',['prepare',['../class_category_chef.html#a359f2c8c69a6208824af304d87c72fe1',1,'CategoryChef']]],
  ['problem_4',['Alcoholics with a coding problem',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]]
];

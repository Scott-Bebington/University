var searchData=
[
  ['getavailable_0',['getAvailable',['../class_table.html#ab52ff668157b52ce2d7bc2368e2b5953',1,'Table']]],
  ['getavailablefornumpeople_1',['getAvailableForNumPeople',['../class_floor.html#acddb78505e26d37f0e0e1c1fca219459',1,'Floor']]],
  ['getavailableseats_2',['getAvailableSeats',['../class_floor.html#a92118e01831bed06fa08b7afda9a5884',1,'Floor']]],
  ['getavailabletables_3',['getAvailableTables',['../class_floor.html#addeb863ecb961dfc964205b0e0e7bfe7',1,'Floor']]],
  ['getcombinedtable_4',['getCombinedTable',['../class_table.html#a0097e07cb925c3392e2b1a0abde31fbf',1,'Table']]],
  ['getfirstavailabletable_5',['getFirstAvailableTable',['../class_floor.html#aefba17c689b71397fd2be36119c72f79',1,'Floor']]],
  ['getnext_6',['getNext',['../class_table.html#a13054bcd80395b3eb8684d06e8faa101',1,'Table']]],
  ['getnumber_7',['getNumber',['../class_table.html#aa0d99400a873ac7ef312224058d506e8',1,'Table']]],
  ['getprevious_8',['getPrevious',['../class_table.html#a45c1770766e257fc08ef530c96e21c65',1,'Table']]],
  ['getsize_9',['getSize',['../class_table.html#a969f7afdade23b3eb84bc4955caaf636',1,'Table']]],
  ['getwaiter_10',['getWaiter',['../class_table.html#a75624b972cccf42cec88168188f26ca7',1,'Table']]]
];

var searchData=
[
  ['ingredients_0',['Ingredients',['../class_ingredients.html',1,'']]]
];

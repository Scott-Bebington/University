var searchData=
[
  ['faster_20less_20obtuse_0',['Reason: faster, less obtuse',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['floor_1',['Floor',['../class_floor.html',1,'']]],
  ['food_2',['Food',['../struct_food.html',1,'']]],
  ['function_20and_20class_20declarations_3',['Brackets on same line with function and class declarations',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];

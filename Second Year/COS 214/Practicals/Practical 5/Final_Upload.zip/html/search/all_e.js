var searchData=
[
  ['reason_3a_20faster_20less_20obtuse_0',['Reason: faster, less obtuse',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['remove_1',['remove',['../class_floor.html#ac8e1a5aa68523afea71e34cf745960ca',1,'Floor']]]
];

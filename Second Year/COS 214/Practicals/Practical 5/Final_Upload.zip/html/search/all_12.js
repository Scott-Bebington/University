var searchData=
[
  ['variables_0',['Variables',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];

var searchData=
[
  ['delegateorder_0',['delegateOrder',['../class_head_chef.html#ad0f9f1858e4c14f423576acbdd671b13',1,'HeadChef']]],
  ['detach_1',['detach',['../class_floor.html#a617b3c2a4a98a67a0d23309207562091',1,'Floor']]]
];

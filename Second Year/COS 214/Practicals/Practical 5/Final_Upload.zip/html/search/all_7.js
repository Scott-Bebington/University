var searchData=
[
  ['headchef_0',['HeadChef',['../class_head_chef.html',1,'']]],
  ['headers_20use_20pragma_20once_20instead_20of_20ifndef_20define_1',['Headers use &apos;#pragma once&apos; instead of &apos;#ifndef...#define&apos;',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]]
];

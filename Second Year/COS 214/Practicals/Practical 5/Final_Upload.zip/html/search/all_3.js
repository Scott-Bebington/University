var searchData=
[
  ['database_0',['Database',['../class_database.html',1,'']]],
  ['declarations_1',['Brackets on same line with function and class declarations',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['define_2',['Headers use &apos;#pragma once&apos; instead of &apos;#ifndef...#define&apos;',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['delegateorder_3',['delegateOrder',['../class_head_chef.html#ad0f9f1858e4c14f423576acbdd671b13',1,'HeadChef']]],
  ['detach_4',['detach',['../class_floor.html#a617b3c2a4a98a67a0d23309207562091',1,'Floor']]],
  ['dish_5',['Dish',['../class_dish.html',1,'']]]
];

var searchData=
[
  ['plateorder_0',['plateOrder',['../class_head_chef.html#acec54e7b6909bec957d25efc3dbd1fd6',1,'HeadChef']]],
  ['prepare_1',['prepare',['../class_category_chef.html#a359f2c8c69a6208824af304d87c72fe1',1,'CategoryChef']]]
];

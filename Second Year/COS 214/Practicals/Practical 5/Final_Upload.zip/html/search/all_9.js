var searchData=
[
  ['less_20obtuse_0',['Reason: faster, less obtuse',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['line_20with_20function_20and_20class_20declarations_1',['Brackets on same line with function and class declarations',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];

var searchData=
[
  ['obtuse_0',['Reason: faster, less obtuse',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['of_20ifndef_20define_1',['Headers use &apos;#pragma once&apos; instead of &apos;#ifndef...#define&apos;',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['on_20same_20line_20with_20function_20and_20class_20declarations_2',['Brackets on same line with function and class declarations',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['once_20instead_20of_20ifndef_20define_3',['Headers use &apos;#pragma once&apos; instead of &apos;#ifndef...#define&apos;',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['order_4',['Order',['../class_order.html',1,'']]],
  ['orderbackup_5',['OrderBackup',['../class_order_backup.html',1,'']]]
];

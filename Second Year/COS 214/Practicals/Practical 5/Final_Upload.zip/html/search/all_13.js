var searchData=
[
  ['waiter_0',['Waiter',['../class_waiter.html',1,'']]],
  ['with_20a_20coding_20problem_1',['Alcoholics with a coding problem',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['with_20function_20and_20class_20declarations_2',['Brackets on same line with function and class declarations',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];

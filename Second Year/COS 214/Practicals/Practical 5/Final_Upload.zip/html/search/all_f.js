var searchData=
[
  ['same_20line_20with_20function_20and_20class_20declarations_0',['Brackets on same line with function and class declarations',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['setavailable_1',['setAvailable',['../class_table.html#a344e009db709ed44a259cf1633556c6e',1,'Table']]],
  ['setcombinedtable_2',['setCombinedTable',['../class_table.html#afff1518e3f4172a5a42375593f55d036',1,'Table']]],
  ['setnext_3',['setNext',['../class_table.html#a74cb22dc214c615f2dbe7c96f2b4f331',1,'Table']]],
  ['setprevious_4',['setPrevious',['../class_table.html#a5799683b165b621060d389e46bfeefea',1,'Table']]],
  ['setwaiter_5',['setWaiter',['../class_table.html#a221b2af1ec3cfa8dfdbfb47a2c9968eb',1,'Table']]],
  ['split_6',['split',['../class_floor.html#a86b28da752efc6e4a5e51d677f7f85ac',1,'Floor']]],
  ['standards_7',['Coding Standards',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['startorder_8',['startOrder',['../class_head_chef.html#a5e863fcf5612b4513ff446264a25ca67',1,'HeadChef']]]
];

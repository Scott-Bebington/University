var searchData=
[
  ['database_0',['Database',['../class_database.html',1,'']]],
  ['dish_1',['Dish',['../class_dish.html',1,'']]]
];

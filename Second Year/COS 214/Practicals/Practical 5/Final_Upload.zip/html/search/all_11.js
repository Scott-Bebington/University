var searchData=
[
  ['updateavailability_0',['updateAvailability',['../class_floor.html#a9494c8c2ffa559a575cbab701c3496cc',1,'Floor']]],
  ['use_20pragma_20once_20instead_20of_20ifndef_20define_1',['Headers use &apos;#pragma once&apos; instead of &apos;#ifndef...#define&apos;',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]]
];

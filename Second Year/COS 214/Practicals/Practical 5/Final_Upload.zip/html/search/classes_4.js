var searchData=
[
  ['headchef_0',['HeadChef',['../class_head_chef.html',1,'']]]
];

var searchData=
[
  ['ifndef_20define_0',['Headers use &apos;#pragma once&apos; instead of &apos;#ifndef...#define&apos;',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['ingredients_1',['Ingredients',['../class_ingredients.html',1,'']]],
  ['instead_20of_20ifndef_20define_2',['Headers use &apos;#pragma once&apos; instead of &apos;#ifndef...#define&apos;',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]]
];

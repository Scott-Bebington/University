#ifndef STORYTELLER_H
#define STORYTELLER_H

#include <string>
#include <iostream>

using namespace std;

class storyteller
{
private:
public:
    storyteller();
    void waveOne();
    void waveTwo();
};

#endif // !STORYTELLER_H

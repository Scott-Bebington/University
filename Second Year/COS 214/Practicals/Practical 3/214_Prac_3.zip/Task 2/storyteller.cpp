#include "storyteller.h"

storyteller::storyteller()
{
}

void storyteller::waveOne()
{
    cout << "Wave One" << endl;
}

void storyteller::waveTwo()
{
    cout << "Wave Two" << endl;
}

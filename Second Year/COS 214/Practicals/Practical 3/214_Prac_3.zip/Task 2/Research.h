#ifndef RESEARCH_H
#define RESEARCH_H

#include <iostream>
#include <string>

using namespace std;

class research
{
private:
    int trapsResearched;

public:
    research();
    int researchList();
    int researchTrap();
};

#endif  // RESEARCH_H
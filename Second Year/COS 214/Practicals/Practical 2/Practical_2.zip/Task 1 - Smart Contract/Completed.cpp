#include "Completed.h"
#include "Context.h"

#include <iostream>

using namespace std;

Completed::Completed() 
{

}

void Completed::handleChange(Context *c)
{
    
}

std::string Completed::getState() {
    return "Completed";
}

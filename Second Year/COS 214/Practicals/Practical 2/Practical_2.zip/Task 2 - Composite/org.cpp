#include "org.h"
#include <iostream>

org::org() {}

org::~org() {}

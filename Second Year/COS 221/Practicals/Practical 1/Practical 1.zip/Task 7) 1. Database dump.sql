-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.11.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table u21546216_bookshopsystem.library
CREATE TABLE IF NOT EXISTS `library` (
  `BookName` text NOT NULL,
  `Edition` tinyint(2) DEFAULT NULL,
  `BookID` int(11) NOT NULL,
  `DateOfIssue` date NOT NULL,
  `StudentBorrowing` int(8) NOT NULL,
  `DateBorrowed` date NOT NULL,
  PRIMARY KEY (`BookID`),
  KEY `StudentBorrowing` (`StudentBorrowing`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table u21546216_bookshopsystem.library: ~0 rows (approximately)
/*!40000 ALTER TABLE `library` DISABLE KEYS */;
INSERT INTO `library` (`BookName`, `Edition`, `BookID`, `DateOfIssue`, `StudentBorrowing`, `DateBorrowed`) VALUES
	('Introduction to Computer Science', 2, 101, '2022-02-23', 21002345, '2022-03-01'),
	('Discrete Mathematics', 3, 102, '2021-12-01', 20007890, '2022-02-15'),
	('Chemistry: The Central Science', 4, 103, '2022-01-12', 22006543, '2022-02-10'),
	('Physics for Scientists and Eng.', NULL, 104, '2022-02-14', 21005678, '2022-02-28'),
	('Environmental Science', 1, 105, '2021-11-28', 22001234, '2022-01-15'),
	('Artificial Intelligence', 2, 106, '2022-03-04', 20076543, '2022-03-08'),
	('Psychology: Themes and Variations', 5, 107, '2022-01-21', 22006789, '2022-03-01'),
	('Fundamentals of Marketing', NULL, 108, '2022-02-08', 21005678, '2022-02-14'),
	('The Art of Public Speaking', 3, 109, '2022-03-01', 20002345, '2022-03-04'),
	('Statistics for Business and Econ.', 2, 110, '2022-01-15', 21008976, '2022-02-01'),
	('Human Anatomy and Physiology', NULL, 111, '2022-02-20', 21001234, '2022-03-05'),
	('The Elements of Style', 4, 112, '2022-02-10', 20005678, '2022-02-18'),
	('Mechanics of Materials', 1, 113, '2022-03-03', 22004567, '2022-03-07'),
	('Calculus: Early Transcendentals', NULL, 114, '2022-02-01', 21003210, '2022-02-15'),
	('Introduction to Sociology', 9, 115, '2021-12-10', 20004567, '2022-01-05'),
	('Principles of Accounting', 3, 116, '2022-03-05', 21002345, '2022-03-06'),
	('Fundamentals of Engineering', NULL, 117, '2022-02-28', 22001234, '2022-03-02'),
	('Microbiology: An Introduction', 13, 118, '2022-03-02', 20007890, '2022-03-04'),
	('Financial Accounting', 8, 119, '2022-01-30', 21005678, '2022-02-05'),
	('Principles of Microeconomics', 7, 120, '2022-02-01', 21001234, '2022-03-01');
/*!40000 ALTER TABLE `library` ENABLE KEYS */;

-- Dumping structure for table u21546216_bookshopsystem.students
CREATE TABLE IF NOT EXISTS `students` (
  `StudentNumber` int(8) NOT NULL,
  `FirstName` text DEFAULT NULL,
  `LastName` text DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Degree` text DEFAULT NULL,
  `IsRegistered` binary(1) DEFAULT NULL,
  PRIMARY KEY (`StudentNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table u21546216_bookshopsystem.students: ~0 rows (approximately)
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`StudentNumber`, `FirstName`, `LastName`, `DateOfBirth`, `Degree`, `IsRegistered`) VALUES
	(20002345, 'Jacob', 'Cooper', '2001-06-16', 'Bachelor of Science in Nursing', _binary 0x30),
	(20004567, 'Zoe', 'Gray', '2002-03-21', 'Bachelor of Science in Geology', _binary 0x30),
	(20005678, 'Lily', 'Wright', '2000-09-15', 'Bachelor of Fine Arts in Graphic Design', _binary 0x30),
	(20006789, 'Gabriel', 'Powell', '2003-12-07', 'Bachelor of Arts in Sociology', _binary 0x31),
	(20007890, 'Mia', 'Torres', '2002-11-05', 'Bachelor of Arts in History', _binary 0x31),
	(20076543, 'Tyler', 'Campbell', '2001-09-14', 'Bachelor of Arts in Psychology', _binary 0x31),
	(21000987, 'Wyatt', 'Kim', '2003-08-04', 'Bachelor of Science in Environmental Science', _binary 0x31),
	(21002345, 'Oliver', 'Flores', '2001-02-22', 'Bachelor of Arts in English', _binary 0x31),
	(21003210, 'Harper', 'Reed', '2000-05-27', 'Bachelor of Science in Exercise Science', _binary 0x31),
	(21005678, 'Evan', 'Green', '2000-12-01', 'Bachelor of Science in Mathematics', _binary 0x30),
	(21007654, 'Benjamin', 'Brooks', '2001-02-23', 'Bachelor of Science in Nutrition', _binary 0x31),
	(21008976, 'Blake', 'Evans', '2003-04-08', 'Bachelor of Business Administration', _binary 0x31),
	(21546216, 'Scott', 'Bebington', '2001-12-25', 'Bachelor of Science in Computer Science', _binary 0x31),
	(22001234, 'Logan', 'Wood', '2003-04-26', 'Bachelor of Arts in Communications', _binary 0x31),
	(22003210, 'Mason', 'Carter', '2001-10-10', 'Bachelor of Science in Physics', _binary 0x31),
	(22004567, 'Amelia', 'Martinez', '2000-07-25', 'Bachelor of Science in Engineering', _binary 0x30),
	(22006543, 'Chloe', 'Young', '2002-07-13', 'Bachelor of Arts in Music', _binary 0x31),
	(22006789, 'Sofia', 'Ramirez', '2002-03-18', 'Bachelor of Science in Biology', _binary 0x30),
	(22007654, 'Ava', 'Parker', '2003-01-12', 'Bachelor of Science in Chemistry', _binary 0x31),
	(22008976, 'Madison', 'Rivera', '2000-01-05', 'Bachelor of Science in Mechanical Engineering', _binary 0x30);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;

public class SQLQueries {
    private String StaffPopulateStatement = "SELECT s.first_name AS Name, s.last_name AS Surname, a.phone AS Phone, "
            + "a.address AS Address, a.address2 AS Address_2, a.district AS District, "
            + "c.city AS City, a.postal_code AS Postal_Code, s.store_id AS Store_ID, "
            + "s.active AS Active "
            + "FROM u21546216_sakila.staff s "
            + "JOIN u21546216_sakila.address a ON s.address_id = a.address_id "
            + "JOIN u21546216_sakila.city c ON a.city_id = c.city_id "
            + "ORDER BY Name, Surname, Phone, Address, Address_2, District, City, Postal_Code, Store_ID, Active;";

    public String StaffPopulate() {
        return StaffPopulateStatement;
    }

    private String FilmsPopulateStatement = "SELECT film_id AS 'Film ID', "
            + "title AS Title, "
            + "description AS Description, "
            + "release_year AS Year, "
            + "rating AS Rating, "
            + "rental_rate AS 'Rental Cost', "
            + "replacement_cost AS 'Replacement Cost' "
            + "FROM film;";

    public String FIlmsPopulate() {
        return FilmsPopulateStatement;
    }

    private String CheckClient = "";

    public void setClientID(int ID) {
        CheckClient = "SELECT * FROM u21546216_sakila.customer "
                + "JOIN u21546216_sakila.address "
                + "ON u21546216_sakila.customer.address_id = u21546216_sakila.address.address_id "
                + "WHERE u21546216_sakila.customer.customer_id = " + ID + ";";
    }

    public String getClient() {
        return CheckClient;
    }

    private String DeleteClient = "";

    public void setDeleteID(int ID) {
        DeleteClient = "delete from u21546216_sakila.customer "
                + "WHERE customer_id = " + ID + ";";
    }

    public String getDeleteStatement() {
        return DeleteClient;
    }

    private String UpdateClient = "";

    public void setUpdateID(int ID) {
        UpdateClient = "delete from u21546216_sakila.customer "
                + "WHERE customer_id = " + ID + ";";

    }

    public String getUpdateStatement() {
        return UpdateClient;
    }

    private String ClientsList = "SELECT * "
            + "FROM u21546216_sakila.customer "
            + "Join u21546216_sakila.address "
            + "ON u21546216_sakila.address.address_id = u21546216_sakila.customer.address_id;";

    public String getClientList() {
        return ClientsList;
    }

    private String ReportsTable = "SELECT inventory.store_id AS 'Store ID', name AS 'Genre', COUNT(*) AS 'Number of Films' "
                                + "FROM inventory "
                                + "INNER JOIN film_category ON inventory.film_id = film_category.film_id "
                                + "INNER JOIN category ON film_category.category_id = category.category_id "
                                + "GROUP BY inventory.store_id, name "
                                + "order by name, store_id;";
    public String getReportsTable()
    {
        return ReportsTable;
    }

    private String AddressID = "SELECT address_id "
                                + "FROM address "
                                + "order by address_id DESC "
                                + "LIMIT 1 ";
    public String getAddressID()
    {
        return AddressID;
    }

    private String CustomerID = "SELECT customer_id "
                                + "FROM customer "
                                + "order by customer_id DESC "
                                + "LIMIT 1 ";
    public String getCustomerID()
    {
        return CustomerID;
    }

    
    private String PopulateDeleteDropdown = "SELECT * FROM film;";
    public String GetDeleteDropdown()
    {
        return PopulateDeleteDropdown;
    }
    
    private String DeleteFilmCheck = "";
    public void setDeleteFilm(int ID)
    {
        DeleteFilmCheck = "SELECT * "
                        + "FROM film "
                        + "INNER JOIN language "
                        + "ON language.language_id = film.language_id "
                        + "WHERE film_id = " + ID + ";";
                        
    }
    public String getDeleteFilm()
    {
        return DeleteFilmCheck;
    }
}

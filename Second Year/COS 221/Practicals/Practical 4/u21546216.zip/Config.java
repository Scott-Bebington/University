// public class Config {

//     private String DBURL = "jdbc:mariadb://localhost:3306/u21546216_sakila";
//     private String Username = "root";
//     private String Password = "Scott25121";
//     private String classname = "org.mariadb.jdbc.Driver";

//     public String getDBURL() {
//         return DBURL;
//     }

//     public String getUsername() {
//         return Username;
//     }

//     public String getPassword() {
//         return Password;
//     }

//     public String getClassName() {
//         return classname;
//     }
// }


public class Config {

    private String DBURL = System.getenv("dvdrental_DB_PROTO") + "://" + System.getenv("dvdrental_DB_HOST") + ":" + System.getenv("dvdrental_DB_PORT") + "/" + System.getenv("dvdrental_DB_NAME");
    private String Username = System.getenv("dvdrental_DB_USERNAME");
    private String Password = System.getenv("dvdrental_DB_PASSWORD");
    private String classname = "org.mariadb.jdbc.Driver";

    public String getDBURL() {
        return DBURL;
    }

    public String getUsername() {
        return Username;
    }

    public String getPassword() {
        return Password;
    }

    public String getClassName() {
        return classname;
    }
}



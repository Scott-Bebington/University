make sure you have the mariadb driver installed, in vscode add the driver to the references libraries in the java projects

Then open a terminal and set the environment variables 

Then run the homepage.java page.
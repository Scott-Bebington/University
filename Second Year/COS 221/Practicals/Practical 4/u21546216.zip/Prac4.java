// import java.sql.*;
// import java.util.logging.Level;
// import java.util.logging.Logger;

// public class Prac4 {
//     public static void main(String[] args) {
//         System.out.println("Welcome to sakila");

//         Connection dbConnection = null;
//         Statement sqlSt = null;
//         ResultSet result = null;

//         String SQL = "SELECT * FROM u21546216_sakila.film "
//                     +    "ORDER BY film_id DESC " 
//                     +    "LIMIT 1;";

//         System.out.println();
//         try {
//             Class.forName("org.mariadb.jdbc.Driver");
//             String dbURL = "jdbc:mariadb://localhost:3306/u21546216_sakila";

//             dbConnection = DriverManager.getConnection(dbURL, "root", "Scott25121");
//             sqlSt = dbConnection.createStatement();
//             result = sqlSt.executeQuery(SQL);
//             while (result.next()) 
//             {
//                 int output =Integer.parseInt( result.getString("film_id"));
//                 System.out.println("Old id: " + output);

//                 int newID = output + 1;
//                 System.out.println("New id: " + newID);
//             }

//         } catch (ClassNotFoundException ex) {
//             Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
//             System.out.println("Class not found, check the JAR");
//         } catch (SQLException ex) {
//             Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
//             System.out.println("SQL error: " + ex.getMessage());
//         } finally {
//             try {
//                 if (result != null) result.close();
//                 if (sqlSt != null) sqlSt.close();
//                 if (dbConnection != null) dbConnection.close();
//             } catch (SQLException ex) {
//                 Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
//                 System.out.println("Error closing database resources: " + ex.getMessage());
//             }
//         }
//     }
// }

public class Prac4 {
    public static void main(String[] args) 
    {
        HomePage form = new HomePage();
        // form.setSize(800, 650);
        form.setLocationRelativeTo(null);
        form.setVisible(true);
    }
}

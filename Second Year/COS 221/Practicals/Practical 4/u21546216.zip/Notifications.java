/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.util.ArrayList;
import java.util.List;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @author scott
 */
public class Notifications extends javax.swing.JFrame {
	public Notifications() {
		initComponents();
	}

	private void initComponents()
    {

        Homepage_Container = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        Home_Page = new javax.swing.JButton();
        Staff_Page = new javax.swing.JButton();
        Films_Page = new javax.swing.JButton();
        Reports_Page = new javax.swing.JButton();
        Notifications_Page = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        SearchBar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Notifications_List_Clients_Table = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        SearchBar_Inactive = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        ClientsTableInactive = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        Add_FName = new javax.swing.JTextField();
        ADD_SName = new javax.swing.JTextField();
        Add_Email = new javax.swing.JTextField();
        Add_Active = new javax.swing.JTextField();
        Add_Back_Button = new javax.swing.JButton();
        Add_Button = new javax.swing.JButton();
        Add_Store_ID = new javax.swing.JComboBox<>();
        Add_Address1 = new javax.swing.JTextField();
        Add_Address2 = new javax.swing.JTextField();
        Add_District = new javax.swing.JTextField();
        Add_Postal_Code = new javax.swing.JTextField();
        Add_City_Dropbox = new javax.swing.JComboBox<>();
        Add_Phone_Number = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        Update_Cust_ID = new javax.swing.JTextField();
        Update_Store_ID_Output = new javax.swing.JTextField();
        Update_FName_Output = new javax.swing.JTextField();
        Update_SName_Output = new javax.swing.JTextField();
        Update_Email_Output = new javax.swing.JTextField();
        Update_Active_Output = new javax.swing.JTextField();
        Update_Button = new javax.swing.JButton();
        Update_Back_Button = new javax.swing.JButton();
        Update_Check_Client_Button = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        Address1_Output = new javax.swing.JTextField();
        Address2_Output = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        Update_StoreID_Input = new javax.swing.JTextField();
        Update_FName_Input = new javax.swing.JTextField();
        Update_LName_Input = new javax.swing.JTextField();
        Update_Email_Input = new javax.swing.JTextField();
        Update_Active_Input = new javax.swing.JTextField();
        Update_Address1_Input = new javax.swing.JTextField();
        Update_Address2_Input = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jPanel4 = new javax.swing.JPanel();
        Delete_FName = new javax.swing.JTextField();
        Delete_SName = new javax.swing.JTextField();
        Delete_Email = new javax.swing.JTextField();
        Delete_Button = new javax.swing.JButton();
        Delete_Back_Button = new javax.swing.JButton();
        Delete_Cust_ID = new javax.swing.JTextField();
        Delete_Client_Check_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Homepage_Container.setBackground(new java.awt.Color(255, 255, 255));

        jSeparator1.setBackground(new java.awt.Color(255, 255, 255));
        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator1.setAlignmentX(0.0F);
        jSeparator1.setAlignmentY(0.0F);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Notifications");

        Home_Page.setText("Home");
        Home_Page.setPreferredSize(new java.awt.Dimension(75, 25));
        Home_Page.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                Home_PageActionPerformed(evt);
            }
        });

        Staff_Page.setText("Staff");
        Staff_Page.setPreferredSize(new java.awt.Dimension(75, 25));
        Staff_Page.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                Staff_PageActionPerformed(evt);
            }
        });

        Films_Page.setText("Films");
        Films_Page.setPreferredSize(new java.awt.Dimension(75, 25));
        Films_Page.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                Films_PageActionPerformed(evt);
            }
        });

        Reports_Page.setText("Reports");
        Reports_Page.setPreferredSize(new java.awt.Dimension(75, 25));
        Reports_Page.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                Reports_PageActionPerformed(evt);
            }
        });

        Notifications_Page.setText("Notifications");
        Notifications_Page.setPreferredSize(new java.awt.Dimension(75, 25));

        Exit.setText("Exit");
        Exit.setPreferredSize(new java.awt.Dimension(75, 25));
        Exit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                ExitActionPerformed(evt);
            }
        });

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        SearchBar.setText("Search...");
        SearchBar.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                SearchBarMouseClicked(evt);
            }
        });
        SearchBar.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyReleased(java.awt.event.KeyEvent evt)
            {
                SearchBarKeyReleased(evt);
            }
        });

        // Notifications_List_Clients_Table.setModel(new javax.swing.table.DefaultTableModel(
        //     new Object[][]
        //     {
        //         {"John", "Doe", "johndoe@example.com", null, null},
        //         {"Jane", "Doe", "janedoe@example.com", null, null},
        //         {"Bob", "Smith", "bobsmith@example.com", null, null},
        //         {"Alice", "Jones", "alicejones@example.com", null, null}
        //     },
        //     new String[]
        //     {
        //         "First Name", "Last Name", "Email", "Address 1", "Address 2"
        //     }

        // )
        // {
        //     boolean[] canEdit = new boolean []
        //     {
        //         false, false, false
        //     };

        //     public boolean isCellEditable(int rowIndex, int columnIndex)
        //     {
        //         return canEdit [columnIndex];
        //     }
        // });

		Connection conn = null;
		Statement stmt = null;
		String sql = null;
		ResultSet rs = null;
		try {
			Class.forName(ClassName);
			conn = DriverManager.getConnection(DBURL, Username, Password);
			stmt = conn.createStatement();
			sql = SQLLink.getClientList();
			rs = stmt.executeQuery(sql);

			DefaultTableModel model = new DefaultTableModel(
					new Object[] { "Customer ID", "First Name", "Last Name", "Email", "Address 1",
							"Address 2" },
					0);

			while (rs.next()) {
				String ID = rs.getString("customer_id");
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String email = rs.getString("email");
				String address1 = rs.getString("address");
				String address2 = rs.getString("address2");
				int active = rs.getInt("active");

				Object[] row = { ID, firstName, lastName, email, address1, address2 };
				if(active == 1)
				{
					model.addRow(row);
				}
			}

			Notifications_List_Clients_Table.setModel(model);

			rs.close();
			stmt.close();
			conn.close();
		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("Class not found, check the JAR");
		} catch (SQLException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("SQL error: " + ex.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("Error closing database resources: " + ex.getMessage());
			}
		}


        Notifications_List_Clients_Table.setGridColor(new java.awt.Color(0, 0, 0));
        Notifications_List_Clients_Table.setOpaque(false);
        jScrollPane1.setViewportView(Notifications_List_Clients_Table);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 596, Short.MAX_VALUE)
                    .addComponent(SearchBar))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(SearchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("List Clients Active", jPanel1);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        SearchBar_Inactive.setText("Search...");

        // ClientsTableInactive.setModel(new javax.swing.table.DefaultTableModel(
        //     new Object[][]
        //     {
        //         {"John", "Doe", "johndoe@example.com", null, null},
        //         {"Jane", "Doe", "janedoe@example.com", null, null},
        //         {"Bob", "Smith", "bobsmith@example.com", null, null},
        //         {"Alice", "Jones", "alicejones@example.com", null, null}
        //     },
        //     new String[]
        //     {
        //         "First Name", "Last Name", "Email", "Address 1", "Address 2"
        //     }

        // )


		conn = null;
		stmt = null;
		sql = null;
		rs = null;
		try {
			Class.forName(ClassName);
			conn = DriverManager.getConnection(DBURL, Username, Password);
			stmt = conn.createStatement();
			sql = SQLLink.getClientList();
			rs = stmt.executeQuery(sql);

			DefaultTableModel model = new DefaultTableModel(
					new Object[] { "Customer ID", "First Name", "Last Name", "Email", "Address 1",
							"Address 2" },
					0);

			while (rs.next()) {
				String ID = rs.getString("customer_id");
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String email = rs.getString("email");
				String address1 = rs.getString("address");
				String address2 = rs.getString("address2");
				int active = rs.getInt("active");

				Object[] row = { ID, firstName, lastName, email, address1, address2 };
				if(active == 0)
				{
					model.addRow(row);
				}
			}

			ClientsTableInactive.setModel(model);

			rs.close();
			stmt.close();
			conn.close();
		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("Class not found, check the JAR");
		} catch (SQLException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("SQL error: " + ex.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("Error closing database resources: " + ex.getMessage());
			}
		}
    // );
    jScrollPane2.setViewportView(ClientsTableInactive);

    javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
    jPanel7.setLayout(jPanel7Layout);
    jPanel7Layout.setHorizontalGroup(
        jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 596, Short.MAX_VALUE)
                .addComponent(SearchBar_Inactive))
            .addContainerGap())
    );
    jPanel7Layout.setVerticalGroup(
        jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel7Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(SearchBar_Inactive, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
            .addContainerGap())
    );

    javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
    jPanel5.setLayout(jPanel5Layout);
    jPanel5Layout.setHorizontalGroup(
        jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );
    jPanel5Layout.setVerticalGroup(
        jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );

    jTabbedPane1.addTab("List Clients Inactive", jPanel5);

    jPanel2.setBackground(new java.awt.Color(255, 255, 255));
    jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

    Add_FName.setText("First Name");
    Add_FName.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Add_FNameMouseClicked(evt);
        }
    });

    ADD_SName.setText("Last Name");
    ADD_SName.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            ADD_SNameMouseClicked(evt);
        }
    });

    Add_Email.setText("Email Address");
    Add_Email.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Add_EmailMouseClicked(evt);
        }
    });

    Add_Active.setText("Active");
    Add_Active.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Add_ActiveMouseClicked(evt);
        }
    });

    Add_Back_Button.setText("Back");
    Add_Back_Button.addActionListener(new java.awt.event.ActionListener()
    {
        public void actionPerformed(java.awt.event.ActionEvent evt)
        {
            Add_Back_ButtonActionPerformed(evt);
        }
    });

    Add_Button.setText("Add Client");
    Add_Button.addActionListener(new java.awt.event.ActionListener()
    {
        public void actionPerformed(java.awt.event.ActionEvent evt)
        {
            Add_ButtonActionPerformed(evt);
        }
    });

    Add_Store_ID.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Store ID", "1", "2"}));

    Add_Address1.setText("Address 1");
    Add_Address1.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Add_Address1MouseClicked(evt);
        }
    });

    Add_Address2.setText("Address 2");
    Add_Address2.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Add_Address2MouseClicked(evt);
        }
    });

    Add_District.setText("District");
    Add_District.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Add_DistrictMouseClicked(evt);
        }
    });

    Add_Postal_Code.setText("Postal Code");
    Add_Postal_Code.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Add_Postal_CodeMouseClicked(evt);
        }
    });

    // Add_City_Dropbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "City", "Item 2", "Item 3", "Item 4" }));
	List<String> cityList = new ArrayList<String>();
		conn = null;
		stmt = null;
		rs = null;
		try {
			Class.forName(ClassName);
			conn = DriverManager.getConnection(DBURL, Username, Password);
			System.out.println("Connection Successful");
			stmt = conn.createStatement();

			// execute the query to retrieve the list of city names
			rs = stmt.executeQuery("SELECT * FROM u21546216_sakila.city");

			// iterate through the result set and add each city name to the list
			cityList.add("City");
			while (rs.next()) {
				String city = rs.getString("city");
				cityList.add(city);
			}

			ComboBoxModel<String> cityModel = new DefaultComboBoxModel<String>(
					cityList.toArray(new String[0]));

			// set the ComboBoxModel as the model for the Add_City_Dropbox
			Add_City_Dropbox.setModel(cityModel);
		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("Class not found, check the JAR");
		} catch (SQLException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("SQL error: " + ex.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("Error closing database resources: " + ex.getMessage());
			}
		}

    Add_Phone_Number.setText("Phone Number");
    Add_Phone_Number.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Add_Phone_NumberMouseClicked(evt);
        }
    });

    javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
    jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
            .addGap(6, 6, 6)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                .addComponent(Add_Email, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
                .addComponent(ADD_SName, javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Add_FName, javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Add_Store_ID, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Add_Active)
                .addComponent(Add_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addComponent(Add_Postal_Code, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
                .addComponent(Add_District)
                .addComponent(Add_Address2)
                .addComponent(Add_Address1)
                .addComponent(Add_City_Dropbox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Add_Back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addContainerGap())
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
            .addContainerGap(171, Short.MAX_VALUE)
            .addComponent(Add_Phone_Number, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(160, 160, 160))
    );
    jPanel2Layout.setVerticalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(Add_Address1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(Add_Store_ID, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(Add_FName, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(Add_Address2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(ADD_SName, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(Add_District, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addComponent(Add_Email, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                .addComponent(Add_City_Dropbox))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(Add_Active, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(Add_Postal_Code, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(Add_Phone_Number, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(Add_Back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(Add_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(163, 163, 163))
    );

    jTabbedPane1.addTab("Add Clients", jPanel2);

    jPanel3.setBackground(new java.awt.Color(255, 255, 255));
    jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

    Update_Cust_ID.setText("Customer ID (Required)");
    Update_Cust_ID.setPreferredSize(new java.awt.Dimension(150, 50));
    Update_Cust_ID.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Update_Cust_IDMouseClicked(evt);
        }
    });

    Update_Store_ID_Output.setText("Store ID");
    Update_Store_ID_Output.setPreferredSize(new java.awt.Dimension(150, 50));


    Update_FName_Output.setText("First Name");

    Update_SName_Output.setText("Last Name");

    Update_Email_Output.setText("Email Address");

    Update_Active_Output.setText("Active");

    Update_Button.setText("Update Client");
    Update_Button.setPreferredSize(new java.awt.Dimension(67, 22));
    Update_Button.addActionListener(new java.awt.event.ActionListener()
    {
        public void actionPerformed(java.awt.event.ActionEvent evt)
        {
            Update_ButtonActionPerformed(evt);
        }
    });

    Update_Back_Button.setText("Back");
    Update_Back_Button.addActionListener(new java.awt.event.ActionListener()
    {
        public void actionPerformed(java.awt.event.ActionEvent evt)
        {
            Update_Back_ButtonActionPerformed(evt);
        }
    });

    Update_Check_Client_Button.setText("Check Client");
    Update_Check_Client_Button.addActionListener(new java.awt.event.ActionListener()
    {
        public void actionPerformed(java.awt.event.ActionEvent evt)
        {
            Update_Check_Client_ButtonActionPerformed(evt);
        }
    });

    jLabel2.setText("Customer Details");

    Address1_Output.setText("Address 1");


    Address2_Output.setText("Address 2");

    jLabel3.setText("Details Being Changed");

    Update_StoreID_Input.setText("Store ID");
    Update_StoreID_Input.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Update_StoreID_InputMouseClicked(evt);
        }
    });

    Update_FName_Input.setText("First Name");
    Update_FName_Input.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Update_FName_InputMouseClicked(evt);
        }
    });

    Update_LName_Input.setText("Last Name");
    Update_LName_Input.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Update_LName_InputMouseClicked(evt);
        }
    });

    Update_Email_Input.setText("Email Address");
    Update_Email_Input.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Update_Email_InputMouseClicked(evt);
        }
    });
    Update_Active_Input.setText("Active");
    Update_Active_Input.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Update_Active_InputMouseClicked(evt);
        }
    });

    Update_Address1_Input.setText("Address 1");
    Update_Address1_Input.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Update_Address1_InputMouseClicked(evt);
        }
    });

    Update_Address2_Input.setText("Address 2");
    Update_Address2_Input.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Update_Address2_InputMouseClicked(evt);
        }
    });

    jSeparator3.setBackground(new java.awt.Color(0, 0, 0));
    jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
    jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);

    javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
    jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Update_SName_Output)
                        .addComponent(Update_Email_Output)
                        .addComponent(Address2_Output)
                        .addComponent(Update_Active_Output)
                        .addComponent(Address1_Output)
                        .addComponent(Update_Store_ID_Output, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
                        .addComponent(Update_FName_Output)
                        .addComponent(Update_Back_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGap(42, 42, 42)
                    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(Update_Cust_ID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Update_Address2_Input)
                    .addComponent(Update_Address1_Input)
                    .addComponent(Update_Active_Input)
                    .addComponent(Update_Email_Input, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Update_StoreID_Input)
                    .addComponent(Update_FName_Input)
                    .addComponent(Update_LName_Input)
                    .addComponent(Update_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addComponent(Update_Check_Client_Button, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE))
            .addContainerGap(80, Short.MAX_VALUE))
    );
    jPanel3Layout.setVerticalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                .addComponent(Update_Cust_ID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Update_Check_Client_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(Update_StoreID_Input, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(Update_FName_Input)
                            .addGap(7, 7, 7)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Update_SName_Output, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Update_LName_Input, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(Update_Email_Input, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                                .addComponent(Update_Email_Output))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(Update_Active_Input, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                                .addComponent(Update_Active_Output))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(Update_Address1_Input, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                                .addComponent(Address1_Output))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(Address2_Output, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                                .addComponent(Update_Address2_Input)))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(Update_Store_ID_Output, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(Update_FName_Output, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, Short.MAX_VALUE)))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(Update_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Update_Back_Button, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)))
                .addComponent(jSeparator3))
            .addGap(130, 130, 130))
    );

    jTabbedPane1.addTab("Update Clients", jPanel3);

    jPanel4.setBackground(new java.awt.Color(255, 255, 255));
    jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

    Delete_FName.setText("First Name");

    Delete_SName.setText("Last Name");

    Delete_Email.setText("Email Address");

    Delete_Button.setText("Delete Client");
    Delete_Button.addActionListener(new java.awt.event.ActionListener()
    {
        public void actionPerformed(java.awt.event.ActionEvent evt)
        {
            Delete_ButtonActionPerformed(evt);
        }
    });

    Delete_Back_Button.setText("Back");
    Delete_Back_Button.addActionListener(new java.awt.event.ActionListener()
    {
        public void actionPerformed(java.awt.event.ActionEvent evt)
        {
            Delete_Back_ButtonActionPerformed(evt);
        }
    });

    Delete_Cust_ID.setText("Customer ID (Required)");
    Delete_Cust_ID.setPreferredSize(new java.awt.Dimension(150, 50));
    Delete_Cust_ID.addMouseListener(new java.awt.event.MouseAdapter()
    {
        public void mouseClicked(java.awt.event.MouseEvent evt)
        {
            Delete_Cust_IDMouseClicked(evt);
        }
    });

    Delete_Client_Check_Button.setText("Check to see if client exists");
    Delete_Client_Check_Button.addActionListener(new java.awt.event.ActionListener()
    {
        public void actionPerformed(java.awt.event.ActionEvent evt)
        {
            Delete_Client_Check_ButtonActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
    jPanel4.setLayout(jPanel4Layout);
    jPanel4Layout.setHorizontalGroup(
        jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel4Layout.createSequentialGroup()
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(96, 96, 96)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Delete_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Delete_SName, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Delete_FName, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Delete_Cust_ID, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addComponent(Delete_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(Delete_Back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(206, 206, 206)
                    .addComponent(Delete_Client_Check_Button)))
            .addContainerGap(106, Short.MAX_VALUE))
    );
    jPanel4Layout.setVerticalGroup(
        jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel4Layout.createSequentialGroup()
            .addGap(23, 23, 23)
            .addComponent(Delete_Cust_ID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addComponent(Delete_Client_Check_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(26, 26, 26)
            .addComponent(Delete_FName, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addComponent(Delete_SName, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addComponent(Delete_Email, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(Delete_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(Delete_Back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addContainerGap(132, Short.MAX_VALUE))
    );

    jTabbedPane1.addTab("Delete Clients", jPanel4);

    javax.swing.GroupLayout Homepage_ContainerLayout = new javax.swing.GroupLayout(Homepage_Container);
    Homepage_Container.setLayout(Homepage_ContainerLayout);
    Homepage_ContainerLayout.setHorizontalGroup(
        Homepage_ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Homepage_ContainerLayout.createSequentialGroup()
            .addContainerGap()
            .addGroup(Homepage_ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                .addComponent(Home_Page, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Staff_Page, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Reports_Page, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Films_Page, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Exit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Notifications_Page, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 610, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(17, Short.MAX_VALUE))
    );
    Homepage_ContainerLayout.setVerticalGroup(
        Homepage_ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jSeparator1)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Homepage_ContainerLayout.createSequentialGroup()
            .addContainerGap()
            .addGroup(Homepage_ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addComponent(jTabbedPane1)
                .addGroup(Homepage_ContainerLayout.createSequentialGroup()
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(43, 43, 43)
                    .addComponent(Home_Page, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(62, 62, 62)
                    .addComponent(Staff_Page, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(62, 62, 62)
                    .addComponent(Films_Page, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(62, 62, 62)
                    .addComponent(Reports_Page, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(62, 62, 62)
                    .addComponent(Notifications_Page, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addContainerGap())
    );

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(Homepage_Container, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(Homepage_Container, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );

    pack();
    }// </editor-fold>                        

	private void ExitActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
	}

	private void Reports_PageActionPerformed(java.awt.event.ActionEvent evt) {
		Reports form = new Reports();
		// form.setSize(800, 650);
		form.setLocationRelativeTo(null);
		form.setVisible(true);
		this.dispose();
	}

	private void Films_PageActionPerformed(java.awt.event.ActionEvent evt) {
		Films form = new Films();
		// form.setSize(800, 650);
		form.setLocationRelativeTo(null);
		form.setVisible(true);
		this.dispose();
	}

	private void Staff_PageActionPerformed(java.awt.event.ActionEvent evt) {
		Staff form = new Staff();
		// form.setSize(800, 650);
		form.setLocationRelativeTo(null);
		form.setVisible(true);
		this.dispose();
	}

	private void Home_PageActionPerformed(java.awt.event.ActionEvent evt) {
		HomePage form = new HomePage();
		// form.setSize(800, 650);
		form.setLocationRelativeTo(null);
		form.setVisible(true);
		this.dispose();
	}

	private void Add_Back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {
		Notifications form = new Notifications();
		// form.setSize(800, 650);
		form.setLocationRelativeTo(null);
		form.setVisible(true);
		this.dispose();
	}

	private void Update_Back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {
		Notifications form = new Notifications();
		// form.setSize(800, 650);
		form.setLocationRelativeTo(null);
		form.setVisible(true);
		this.dispose();
	}

	private void Delete_Back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {
		Notifications form = new Notifications();
		// form.setSize(800, 650);
		form.setLocationRelativeTo(null);
		form.setVisible(true);
		this.dispose();
	}

	private void SearchBarKeyReleased(java.awt.event.KeyEvent evt) {
		String searchValue = SearchBar.getText();
		DefaultTableModel tableModel = (DefaultTableModel) Notifications_List_Clients_Table.getModel();
		TableRowSorter<DefaultTableModel> tableRowSorter = new TableRowSorter<>(tableModel);
		Notifications_List_Clients_Table.setRowSorter(tableRowSorter);
		if (searchValue.trim().length() == 0) {
			tableRowSorter.setRowFilter(null);
		} else {
			tableRowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchValue));
		}
	}

	private void SearchBarMouseClicked(java.awt.event.MouseEvent evt) 
	{
		if (SearchBar.getText().equals("Search...")) {
			SearchBar.setText("");
		}
	}

	// Add Client
	private void Add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {
		Connection conn = null;
		Statement stmt = null;
		ResultSet res = null;

		try {
			Class.forName(ClassName);
			conn = DriverManager.getConnection(DBURL, Username, Password);
			stmt = conn.createStatement();

			String temp = SQLLink.getAddressID();

			res = stmt.executeQuery(temp);
			int GetLastAddressID = 0;
			while (res.next()) {
				GetLastAddressID = 1 + Integer.parseInt(res.getString("address_id"));
			}

			System.out.println("Address ID for new customer: " + GetLastAddressID);

			// address_id, address, address2, district, city_id, postal_code, phone,
			// last_update

			String address = Add_Address1.getText();
			String address2 = Add_Address2.getText();
			String district = Add_District.getText();
			int cityid = Add_City_Dropbox.getSelectedIndex();
			if (Add_City_Dropbox.getSelectedItem().toString().equalsIgnoreCase("City")) {
				throw new SQLException("Please select an option for City");
			}
			String postalcode = Add_Postal_Code.getText();
			String phone = Add_Phone_Number.getText();

			LocalDateTime currentDateTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String FormattedDateTime = currentDateTime.format(formatter);

			String InsertAddress = "INSERT INTO address VALUES("
					+ GetLastAddressID + ", '"
					+ address + "', '"
					+ address2 + "', '"
					+ district + "', "
					+ cityid + ", '"
					+ postalcode + "', '"
					+ phone + "', '"
					+ FormattedDateTime + "');";
			System.out.println("SQL Address Insert Statement");
			System.out.println(InsertAddress);
			res.close();
			res = stmt.executeQuery(InsertAddress);

			temp = SQLLink.getCustomerID();

			res.close();
			res = stmt.executeQuery(temp);
			int GetLastCustomerID = 0;
			while (res.next()) {
				GetLastCustomerID = 1 + Integer.parseInt(res.getString("customer_id"));
			}

			System.out.println("Customer ID for new customer: " + GetLastCustomerID);

			// customer_id, store_id, first_name, last_name, email, address_id, active,
			// create_date, last_update
			String StoreID = Add_Store_ID.getSelectedItem().toString();
			if (StoreID.equalsIgnoreCase("Store ID")) {
				throw new SQLException("Please select an option for store ID");
			}
			String FName = Add_FName.getText();
			String SName = ADD_SName.getText();
			String Email = Add_Email.getText();
			// AddressID
			temp = Add_Active.getText();
			int active = 0;
			if (temp.equalsIgnoreCase("yes")
					|| temp.equalsIgnoreCase("True")
					|| temp.equalsIgnoreCase("1")) {
				active = 1;
			}
			// Date
			// Date

			String InsertCustomer = "INSERT INTO customer VALUES("
					+ GetLastCustomerID + ", "
					+ StoreID + ", '"
					+ FName + "', '"
					+ SName + "', '"
					+ Email + "', "
					+ GetLastAddressID + ", "
					+ active + ", '"
					+ FormattedDateTime + "', '"
					+ FormattedDateTime + "'); ";

			System.out.println("SQL Customer Insert Statement");
			System.out.println(InsertCustomer);

			stmt.executeQuery(InsertCustomer);

			System.out.println("Inserted Successfully");

			this.dispose();

			Notifications notif = new Notifications();
			notif.setLocationRelativeTo(null);
			notif.setVisible(true);

			Popup popup = new Popup("Customer Added Successfully");
			popup.setLocationRelativeTo(null);
			popup.setVisible(true);

		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("Class not found, check the JAR");
		} catch (SQLException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("SQL error: " + ex.getMessage());

			this.dispose();

			Notifications notif = new Notifications();
			notif.setLocationRelativeTo(null);
			notif.setVisible(true);

			Popup popup = new Popup(ex.getMessage());
			popup.setLocationRelativeTo(null);
			popup.setVisible(true);
		} finally {
			try {
				if (res != null)
					res.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("Error closing database resources: " + ex.getMessage());
			}
		}
	}

	private void Delete_Cust_IDMouseClicked(java.awt.event.MouseEvent evt) {
		if (Delete_Cust_ID.getText().equals("Customer ID (Required)")) {
			Delete_Cust_ID.setText("");
		}
	}

	private void Delete_Client_Check_ButtonActionPerformed(java.awt.event.ActionEvent evt) {
		DeleteFlag = false;
		if (!Delete_Cust_ID.getText().toString().isEmpty()
				&& !Delete_Cust_ID.getText().toString().equals("Customer ID (Required)")) {
			int ID = Integer.parseInt(Delete_Cust_ID.getText());
			SQLLink.setClientID(ID);

		}
		String SQL = SQLLink.getClient();
		Connection dbConnection = null;
		ResultSet rs = null;
		Statement stmt = null;

		try {
			if (!Delete_Cust_ID.getText().toString().isEmpty()
					&& !Delete_Cust_ID.getText().toString().equals("Customer ID (Required)")) {
				Class.forName(ClassName);
				dbConnection = DriverManager.getConnection(DBURL, Username, Password);
				stmt = dbConnection.createStatement();
				rs = stmt.executeQuery(SQL);
				String output = "";
				String Name = "";
				String Surname = "";
				String Email = "";
				while (rs.next()) {
					Name = rs.getString("first_name");
					Surname = rs.getString("last_name");
					Email = rs.getString("email");
					output = rs.getString("first_name") + " " + rs.getString("last_name");
					System.out.println("Customer Found: " + output);

				}
				if (output != "") {
					Delete_FName.setText(Name);
					Delete_SName.setText(Surname);
					Delete_Email.setText(Email);
					DeleteFlag = true;
				}
			} else {
				String Text = "No client exists with that client ID, please enter another one";
				Delete_FName.setText(Text);
				Delete_SName.setText(Text);
				Delete_Email.setText(Text);
			}

		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("Class not found, check the JAR");
		} catch (SQLException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("SQL error: " + ex.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (dbConnection != null)
					dbConnection.close();
			} catch (SQLException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("Error closing database resources: " + ex.getMessage());
			}
		}
	}

	private void Delete_ButtonActionPerformed(java.awt.event.ActionEvent evt) {
		Delete_Client_Check_ButtonActionPerformed(evt);
		if (DeleteFlag) {

			int ID = Integer.parseInt(Delete_Cust_ID.getText());
			// System.out.println("ID: " + ID);
			SQLLink.setDeleteID(ID);

			String SQL = SQLLink.getDeleteStatement();
			Connection dbConnection = null;
			ResultSet rs = null;
			Statement stmt = null;

			try {

				Class.forName(ClassName);
				dbConnection = DriverManager.getConnection(DBURL, Username, Password);

				String DeleteAddressIDQuery = "SELECT address_id "
						+ "FROM customer "
						+ "WHERE customer_id = " + ID + ";";

				System.out.println(SQL);

				stmt = dbConnection.createStatement();
				rs = stmt.executeQuery(DeleteAddressIDQuery);

				int DeleteAddressID = -1;
				while (rs.next()) {
					DeleteAddressID = rs.getInt("address_id");
					System.out.println(DeleteAddressID);
				}

				stmt.close();
				rs.close();
				stmt = dbConnection.createStatement();
				rs = stmt.executeQuery(SQL);

				String DeleteAddress = "DELETE FROM address WHERE address_id = " + DeleteAddressID + ";";
				System.out.println(DeleteAddress);

				stmt.close();
				rs.close();
				stmt = dbConnection.createStatement();
				rs = stmt.executeQuery(DeleteAddress);

				System.out.println("Deleted Successfully");
				Notifications form = new Notifications();
				// form.setSize(800, 650);
				form.setLocationRelativeTo(null);
				form.setVisible(true);
				this.dispose();

				Popup frame = new Popup("User deleted Successfully");
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			} catch (ClassNotFoundException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("Class not found, check the JAR");
			} catch (SQLException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("SQL error: " + ex.getMessage());
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
					if (dbConnection != null)
						dbConnection.close();
				} catch (SQLException ex) {
					Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
					System.out.println("Error closing database resources: " + ex.getMessage());
				}
			}
		} else {
			Popup PopupFrame = new Popup("User not found, please enter another Client ID and try again");
			PopupFrame.setLocationRelativeTo(null);
			PopupFrame.setVisible(true);
			System.out.println("User not found, Cannot delete");
		}
	}

	private void Update_ButtonActionPerformed(java.awt.event.ActionEvent evt) {
		Update_Check_Client_ButtonActionPerformed(evt);
		if (UpdateFlag) {
			int ID = Integer.parseInt(Update_Cust_ID.getText());
			System.out.println("ID: " + ID);
			SQLLink.setClientID(ID);
			String getClient = SQLLink.getClient();

			// String SQL = SQLLink.getUpdateStatement();
			Connection dbConnection = null;
			ResultSet rs = null;
			Statement stmt = null;

			try {

				Class.forName(ClassName);
				dbConnection = DriverManager.getConnection(DBURL, Username, Password);
				stmt = dbConnection.createStatement();

				rs = stmt.executeQuery(getClient);
				int AddressID = 0;
				while (rs.next()) {

					AddressID = Integer.parseInt(rs.getString("address_id"));
					System.out.println("Address ID: " + AddressID);

				}

				System.out.println("Testing Values");

				String InputStoreID = Update_StoreID_Input.getText();
				String InputFname = Update_FName_Input.getText();
				String InputSName = Update_LName_Input.getText();
				String InputEmail = Update_Email_Input.getText();
				String InputActive = Update_Active_Input.getText();
				String InputAddress1 = Update_Address1_Input.getText();
				String InputAddress2 = Update_Address2_Input.getText();

				String UpdateCustomerSQL = "UPDATE customer "
						+ "SET ";
				String UpdateAddressSQL = "UPDATE address "
						+ "SET ";

				if (!InputStoreID.equals("") && !InputStoreID.equals("Store ID")) {
					System.out.println("Store ID to be updated: " + InputStoreID);
					UpdateCustomerSQL += "store_id = " + InputStoreID + ", ";
				} else {
					System.out.println("No Store ID");
				}
				if (!InputFname.equals("") && !InputFname.equals("First Name")) {
					System.out.println("Name to be updated: " + InputFname);
					UpdateCustomerSQL += "first_name = '" + InputFname + "', ";
				} else {
					System.out.println("No Name");
				}
				if (!InputSName.equals("") && !InputSName.equals("Last Name")) {
					System.out.println("Surname to be updated: " + InputSName);
					UpdateCustomerSQL += "last_name = '" + InputSName + "', ";
				} else {
					System.out.println("No Surname");
				}
				if (!InputEmail.equals("") && !InputEmail.equals("Email Address")) {
					System.out.println("Email to be updated: " + InputEmail);
					UpdateCustomerSQL += "email = '" + InputEmail + "', ";
				} else {
					System.out.println("No Email");
				}
				if (!InputActive.equals("") && !InputActive.equals("Active")) {
					if (InputActive.equalsIgnoreCase("yes")
							|| InputActive.equalsIgnoreCase("true")
							|| InputActive.equalsIgnoreCase("1")) {
						System.out.println("Active to be updated: " + InputActive);
						UpdateCustomerSQL += "active = 1, ";
					} else {
						UpdateCustomerSQL += "active = 0, ";
					}

				} else {
					System.out.println("No Active");
				}
				if (!InputAddress1.equals("") && !InputAddress1.equals("Address 1")) {
					System.out.println("Address 1 to be updated: " + InputAddress1);
					UpdateAddressSQL += "address = '" + InputAddress1 + "', ";
				} else {
					System.out.println("No Address 1");
				}
				if (!InputAddress2.equals("") && !InputAddress2.equals("Address 2")) {
					System.out.println("Address 2 to be updated: " + InputAddress2);
					UpdateAddressSQL += "address2 = '" + InputAddress2 + "', ";
				} else {
					System.out.println("No Address 2");
				}

				System.out.println();

				if (UpdateCustomerSQL.length() > 20) {
					UpdateCustomerSQL = UpdateCustomerSQL.substring(0, UpdateCustomerSQL.length() - 2);
					UpdateCustomerSQL += " WHERE customer_id = " + ID + ";";
					rs.close();
					rs = stmt.executeQuery(UpdateCustomerSQL);
					System.out.println("Customer check is true");
				}

				if (UpdateAddressSQL.length() > 19) {
					UpdateAddressSQL = UpdateAddressSQL.substring(0, UpdateAddressSQL.length() - 2);
					UpdateAddressSQL += " WHERE address_id = " + AddressID + ";";
					rs.close();
					rs = stmt.executeQuery(UpdateAddressSQL);
					System.out.println("Address check is true");
				}

				System.out.println(UpdateCustomerSQL);
				System.out.println(UpdateAddressSQL);

				System.out.println("Customer Query Length: " + UpdateCustomerSQL.length());
				System.out.println("Customer Query Length: " + UpdateAddressSQL.length());

				System.out.println("Updated Successfully");

				this.dispose();

				Notifications notif = new Notifications();
				notif.setLocationRelativeTo(null);
				notif.setVisible(true);

				Popup popup = new Popup("Customer Updated Successfully");
				popup.setLocationRelativeTo(null);
				popup.setVisible(true);

			} catch (ClassNotFoundException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("Class not found, check the JAR");
			} catch (SQLException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("SQL error: " + ex.getMessage());
			} finally {
				try {
					if (rs != null)
						rs.close();
					if (stmt != null)
						stmt.close();
					if (dbConnection != null)
						dbConnection.close();
				} catch (SQLException ex) {
					Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
					System.out.println("Error closing database resources: " + ex.getMessage());
				}
			}
		} else {
			Popup PopupFrame = new Popup("User not found, please enter another Client ID and try again");
			PopupFrame.setLocationRelativeTo(null);
			PopupFrame.setVisible(true);
			System.out.println("User not found, Cannot Update");
		}
	}

	private void Update_Check_Client_ButtonActionPerformed(java.awt.event.ActionEvent evt) {
		UpdateFlag = false;
		if (!Update_Cust_ID.getText().toString().isEmpty()
				&& !Update_Cust_ID.getText().toString().equals("Customer ID (Required)")) {
			int ID = Integer.parseInt(Update_Cust_ID.getText());
			SQLLink.setClientID(ID);

		}
		String SQL = SQLLink.getClient();
		Connection dbConnection = null;
		ResultSet rs = null;
		Statement stmt = null;

		try {
			if (!Update_Cust_ID.getText().toString().isEmpty()
					&& !Update_Cust_ID.getText().toString().equals("Customer ID (Required)")) {
				Class.forName(ClassName);
				dbConnection = DriverManager.getConnection(DBURL, Username, Password);
				stmt = dbConnection.createStatement();
				rs = stmt.executeQuery(SQL);
				String output = "";
				String StoreID = "";
				String Name = "";
				String Surname = "";
				String Email = "";
				String Active = "";
				String Address1 = "";
				String Address2 = "";
				while (rs.next()) {
					StoreID = rs.getString("store_id");
					Name = rs.getString("first_name");
					Surname = rs.getString("last_name");
					Email = rs.getString("email");
					Active = rs.getString("active");
					Address1 = rs.getString("address");
					Address2 = rs.getString("address2");

					output = rs.getString("first_name") + " " + rs.getString("last_name");
					System.out.println("Customer Found: " + output);

				}
				if (output != "") {
					Update_Store_ID_Output.setText(StoreID);
					Update_FName_Output.setText(Name);
					Update_SName_Output.setText(Surname);
					Update_Email_Output.setText(Email);
					Update_Active_Output.setText(Active);
					Address1_Output.setText(Address1);
					Address2_Output.setText(Address2);
					UpdateFlag = true;
				} else {
					String Text = "No client exists, Enter another ID";
					Update_Store_ID_Output.setText(Text);
					Update_FName_Output.setText(Text);
					Update_SName_Output.setText(Text);
					Update_Email_Output.setText(Text);
					Update_Active_Output.setText(Text);
					Address1_Output.setText(Text);
					Address2_Output.setText(Text);
				}
			} else {
				String Text = "No client exists, Enter another ID";
				Update_Store_ID_Output.setText(Text);
				Update_FName_Output.setText(Text);
				Update_SName_Output.setText(Text);
				Update_Email_Output.setText(Text);
				Update_Active_Output.setText(Text);
				Address1_Output.setText(Text);
				Address2_Output.setText(Text);
			}

		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("Class not found, check the JAR");
		} catch (SQLException ex) {
			Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
			System.out.println("SQL error: " + ex.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (dbConnection != null)
					dbConnection.close();
			} catch (SQLException ex) {
				Logger.getLogger(Prac4.class.getName()).log(Level.SEVERE, null, ex);
				System.out.println("Error closing database resources: " + ex.getMessage());
			}
		}
	}

	private void Update_Cust_IDMouseClicked(java.awt.event.MouseEvent evt) {
		if (Update_Cust_ID.getText().equals("Customer ID (Required)")) {
			Update_Cust_ID.setText("");
		}
	}

	private void Update_StoreID_InputMouseClicked(java.awt.event.MouseEvent evt) {
		if (Update_StoreID_Input.getText().equals("Store ID")) {
			Update_StoreID_Input.setText("");
		}
	}

	private void Update_FName_InputMouseClicked(java.awt.event.MouseEvent evt) {
		if (Update_FName_Input.getText().equals("First Name")) {
			Update_FName_Input.setText("");
		}
	}

	private void Update_LName_InputMouseClicked(java.awt.event.MouseEvent evt) {
		if (Update_LName_Input.getText().equals("Last Name")) {
			Update_LName_Input.setText("");
		}
	}

	private void Update_Email_InputMouseClicked(java.awt.event.MouseEvent evt) {
		if (Update_Email_Input.getText().equals("Email Address")) {
			Update_Email_Input.setText("");
		}
	}

	private void Update_Active_InputMouseClicked(java.awt.event.MouseEvent evt) {
		if (Update_Active_Input.getText().equals("Active")) {
			Update_Active_Input.setText("");
		}
	}

	private void Update_Address1_InputMouseClicked(java.awt.event.MouseEvent evt) {
		if (Update_Address1_Input.getText().equals("Address 1")) {
			Update_Address1_Input.setText("");
		}
	}

	private void Update_Address2_InputMouseClicked(java.awt.event.MouseEvent evt) {
		if (Update_Address2_Input.getText().equals("Address 2")) {
			Update_Address2_Input.setText("");
		}
	}

	private void Add_FNameMouseClicked(java.awt.event.MouseEvent evt) {
		if (Add_FName.getText().equals("First Name")) {
			Add_FName.setText("");
		}
	}

	private void ADD_SNameMouseClicked(java.awt.event.MouseEvent evt) {
		if (ADD_SName.getText().equals("Last Name")) {
			ADD_SName.setText("");
		}
	}

	private void Add_EmailMouseClicked(java.awt.event.MouseEvent evt) {
		if (Add_Email.getText().equals("Email Address")) {
			Add_Email.setText("");
		}
	}

	private void Add_ActiveMouseClicked(java.awt.event.MouseEvent evt) {
		if (Add_Active.getText().equals("Active")) {
			Add_Active.setText("");
		}
	}

	private void Add_Phone_NumberMouseClicked(java.awt.event.MouseEvent evt) {
		if (Add_Phone_Number.getText().equals("Phone Number")) {
			Add_Phone_Number.setText("");
		}
	}

	private void Add_Address1MouseClicked(java.awt.event.MouseEvent evt) {
		if (Add_Address1.getText().equals("Address 1")) {
			Add_Address1.setText("");
		}
	}

	private void Add_Address2MouseClicked(java.awt.event.MouseEvent evt) {
		if (Add_Address2.getText().equals("Address 2")) {
			Add_Address2.setText("");
		}
	}

	private void Add_DistrictMouseClicked(java.awt.event.MouseEvent evt) {
		if (Add_District.getText().equals("District")) {
			Add_District.setText("");
		}
	}

	private void Add_Postal_CodeMouseClicked(java.awt.event.MouseEvent evt) {
		if (Add_Postal_Code.getText().equals("Postal Code")) {
			Add_Postal_Code.setText("");
		}
	}

	/**
	 * @param args
	 *             the command line arguments
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		// <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
		// (optional) ">
		/*
		 * If Nimbus (introduced in Java SE 6) is not available, stay with the default
		 * look and feel.
		 * For details see
		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager
					.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(Notifications.class.getName()).log(
					java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(Notifications.class.getName()).log(
					java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(Notifications.class.getName()).log(
					java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(Notifications.class.getName()).log(
					java.util.logging.Level.SEVERE, null,
					ex);
		}
		// </editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Notifications().setVisible(true);
			}
		});
	}

	// Variables declaration - do not modify
	private javax.swing.JTextField ADD_SName;
    private javax.swing.JTextField Add_Active;
    private javax.swing.JTextField Add_Address1;
    private javax.swing.JTextField Add_Address2;
    private javax.swing.JButton Add_Back_Button;
    private javax.swing.JButton Add_Button;
    private javax.swing.JComboBox<String> Add_City_Dropbox;
    private javax.swing.JTextField Add_District;
    private javax.swing.JTextField Add_Email;
    private javax.swing.JTextField Add_FName;
    private javax.swing.JTextField Add_Phone_Number;
    private javax.swing.JTextField Add_Postal_Code;
    private javax.swing.JComboBox<String> Add_Store_ID;
    private javax.swing.JTextField Address1_Output;
    private javax.swing.JTextField Address2_Output;
    private javax.swing.JTable ClientsTableInactive;
    private javax.swing.JButton Delete_Back_Button;
    private javax.swing.JButton Delete_Button;
    private javax.swing.JButton Delete_Client_Check_Button;
    private javax.swing.JTextField Delete_Cust_ID;
    private javax.swing.JTextField Delete_Email;
    private javax.swing.JTextField Delete_FName;
    private javax.swing.JTextField Delete_SName;
    private javax.swing.JButton Exit;
    private javax.swing.JButton Films_Page;
    private javax.swing.JButton Home_Page;
    private javax.swing.JPanel Homepage_Container;
    private javax.swing.JTable Notifications_List_Clients_Table;
    private javax.swing.JButton Notifications_Page;
    private javax.swing.JButton Reports_Page;
    private javax.swing.JTextField SearchBar;
    private javax.swing.JTextField SearchBar_Inactive;
    private javax.swing.JButton Staff_Page;
    private javax.swing.JTextField Update_Active_Input;
    private javax.swing.JTextField Update_Active_Output;
    private javax.swing.JTextField Update_Address1_Input;
    private javax.swing.JTextField Update_Address2_Input;
    private javax.swing.JButton Update_Back_Button;
    private javax.swing.JButton Update_Button;
    private javax.swing.JButton Update_Check_Client_Button;
    private javax.swing.JTextField Update_Cust_ID;
    private javax.swing.JTextField Update_Email_Input;
    private javax.swing.JTextField Update_Email_Output;
    private javax.swing.JTextField Update_FName_Input;
    private javax.swing.JTextField Update_FName_Output;
    private javax.swing.JTextField Update_LName_Input;
    private javax.swing.JTextField Update_SName_Output;
    private javax.swing.JTextField Update_StoreID_Input;
    private javax.swing.JTextField Update_Store_ID_Output;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTabbedPane jTabbedPane1;

	Config NotificationsLink = new Config();
	SQLQueries SQLLink = new SQLQueries();
	String DBURL = NotificationsLink.getDBURL();
	String ClassName = NotificationsLink.getClassName();
	String Username = NotificationsLink.getUsername();
	String Password = NotificationsLink.getPassword();

	Boolean DeleteFlag = false;
	Boolean UpdateFlag = false;
	// End of variables declaration
}

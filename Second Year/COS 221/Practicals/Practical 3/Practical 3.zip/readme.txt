Task 7
1. open HeidiSQL and Create new database called u21546216_bookshopsystem
2. open a new query in the database
3. right click in the query and select "Load SQL file..."
4. Select the data dump file
5. next to ttEncoding tab select utf-8
6. click open
7. run the query
8. both tables should be created and populated
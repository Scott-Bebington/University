public interface ListInterface {
    boolean add(Person person);
    boolean remove(Person person);
    void printQueue();
}

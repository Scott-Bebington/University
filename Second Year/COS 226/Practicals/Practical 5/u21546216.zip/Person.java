public class Person {
    String name;
    long time;

    public Person(String name, long time) {
        this.name = name;
        this.time = time;
    }
}

import java.util.concurrent.atomic.AtomicMarkableReference;

class Window {
    public Node pred, curr;

    Window(Node myPred, Node myCurr) {
        pred = myPred;
        curr = myCurr;
    }

}

public class non_blocking implements ListInterface {

    Node head;

    public Node getHead() {
        return head;
    }

    public non_blocking() {
        head = new Node(Integer.MIN_VALUE);
        head.nextNonBlocking = new AtomicMarkableReference<>(new Node(Integer.MAX_VALUE), false);
    }

    public boolean add(Person item) {
        int key = item.hashCode();
        while (true) {
            Window window = find(head, key);
            Node pred = window.pred, curr = window.curr;
            if (curr.key == key) {
                return false;
            } else {
                Node node = new Node(item);
                node.nextNonBlocking = new AtomicMarkableReference<>(curr, false);
                if (pred.nextNonBlocking.compareAndSet(curr, node, false, false)) {
                    return true;
                }
            }
        }

    }

    public boolean remove(Person item) {
        int key = item.hashCode();
        boolean snip;
        while (true) {
            Window window = find(head, key);
            Node pred = window.pred, curr = window.curr;
            if (curr.key != key) {
                return false;
            } else {
                Node succ = curr.nextNonBlocking.getReference();
                snip = curr.nextNonBlocking.compareAndSet(succ, succ, false, true);
                if (!snip)
                    continue;
                pred.nextNonBlocking.compareAndSet(curr, succ, false, false);
                return true;
            }
        }
    }

    public boolean contains(Person item) {
        boolean[] marked = new boolean[1];
        int key = item.hashCode();
        Node curr = head;
        while (curr.key < key) {
            curr = curr.nextNonBlocking.getReference();
            Node succ = curr.nextNonBlocking.get(marked);
        }
        return (curr.key == key && !marked[0]);
    }

    public Window find(Node head, int key) {
        Node pred = null, curr = null, succ = null;
        boolean[] marked = { false };
        boolean snip;
        retry: while (true) {
            pred = head;
            curr = pred.nextNonBlocking.getReference();
            while (true) {
                succ = curr.nextNonBlocking.get(marked);
                while (marked[0]) {
                    snip = pred.nextNonBlocking.compareAndSet(curr, succ, false, false);
                    if (!snip)
                        continue retry;
                    curr = succ;
                    succ = curr.nextNonBlocking.get(marked);
                }
                if (curr.key >= key)
                    return new Window(pred, curr);
                pred = curr;
                curr = succ;
            }
        }
    }

    public void printQueue() {
        Node curr = head.nextNonBlocking.getReference();
        String str = "Thread-" + getID() + ": ";
        while (curr.nextNonBlocking.getReference() != null) {
            str += "(" + curr.person.name + ", " + curr.person.time + "), ";
            curr = curr.nextNonBlocking.getReference();
        }
        str = str.substring(0, str.length() - 2);
        System.out.println(str + "\n");
    }

    public int getID() {
        return Integer.parseInt(Thread.currentThread().getName().split("-")[1]);
    }

}

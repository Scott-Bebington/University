public class Lazy implements ListInterface {

    Node head;

    public Node getHead() {
        return head;
    }

    public Lazy() {
        head = new Node(Integer.MIN_VALUE);
        head.next = new Node(Integer.MAX_VALUE);
    }

    public boolean add(Person item) {
        int key = item.hashCode();
        while (true) {
            Node pred = head;
            Node curr = head.next;
            while (curr.key < key) {
                pred = curr;
                curr = curr.next;
            }
            pred.l.lock();
            try {
                curr.l.lock();
                try {
                    if (validate(pred, curr)) {
                        if (curr.key == key) {
                            return false;
                        } else {
                            Node node = new Node(item);
                            node.next = curr;
                            pred.next = node;
                            return true;
                        }
                    }
                } finally {
                    curr.l.unlock();
                }
            } finally {
                pred.l.unlock();
            }
        }
    }
    
    public boolean remove(Person item) {
        int key = item.hashCode();
        while (true) {
            Node pred = head;
            Node curr = head.next;
            while (curr.key < key) {
                pred = curr;
                curr = curr.next;
            }
            pred.l.lock();
            try {
                curr.l.lock();
                try {
                    if (validate(pred, curr)) {
                        if (curr.key != key) {
                            return false;
                        } else {
                            curr.marked = true;
                            pred.next = curr.next;
                            return true;
                        }
                    }
                } finally {
                    curr.l.unlock();
                }
            } finally {
                pred.l.unlock();
            }
        }
    }
    
    public boolean contains(Person item) {
        int key = item.hashCode();
        Node curr = head;
        while (curr.key < key)
            curr = curr.next;
        return curr.key == key && !curr.marked;
    }

    private boolean validate(Node pred, Node curr) {
        Node node = head;
        while (node.key <= pred.key) {
            if (node == pred)
                return pred.next == curr;
            node = node.next;
        }
        return false;
    }  
    
    public void printQueue() {
        Node curr = head.next;
        String str = "Thread-" + getID() + ": ";
        while (curr.next != null) {
            str += "(" + curr.person.name + ", " + curr.person.time + "), ";
            curr = curr.next;
        }
        str = str.substring(0, str.length() - 2);
        System.out.println(str + "\n");
    }

    public int getID() {
        return Integer.parseInt(Thread.currentThread().getName().split("-")[1]);
    }

}

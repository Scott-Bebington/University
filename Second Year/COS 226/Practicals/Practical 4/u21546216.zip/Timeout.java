import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class Timeout implements Lock {
    static Node AVAILABLE = new Node();
    AtomicReference<Node> tail;
    ThreadLocal<Node> myNode;

    int count = 0;
    String StartingThread = "";
    boolean flag = true;
    String[] QUEUE = new String[0];

    public Timeout() {
        tail = new AtomicReference<Node>(null);
        myNode = new ThreadLocal<Node>() {
            protected Node initialValue() {
                return new Node();
            }
        };
    }

    public void lock() {

    }

    public void addToQueue(String threadname) {
        String[] temp = new String[QUEUE.length + 1];
        for (int i = 0; i < QUEUE.length; i++) {
            temp[i] = QUEUE[i];
        }
        temp[QUEUE.length] = threadname;
        QUEUE = temp;
    }

    public boolean tryLock() {

        long timeout = 5000;

        Node qnode = new Node();
        qnode.threadname = Thread.currentThread().getName();
        myNode.set(qnode);

        qnode.prev = null;
        Node myPred = tail.getAndSet(qnode);
        if (myPred != null) {
            myPred.next = qnode;
        }

        if (myPred == null
                || myPred.prev == AVAILABLE) {
            return true;
        }

        long start = System.currentTimeMillis();
        while (System.currentTimeMillis() - start < timeout) {
            Node predPred = myPred.prev;
            if (predPred == AVAILABLE) {
                return true;
            } else if (predPred != null) {
                myPred = predPred;
            }
        }
        if (!tail.compareAndSet(qnode,
                myPred))
            qnode.prev = myPred;
        return false;
    }

    public void unlock() {

        // Setting the starting node
        if (flag) {
            StartingThread = Thread.currentThread().getName();
            flag = false;
        }

        Node Node = myNode.get();
        tail.get().count++;

        printQueue();

        if (!tail.compareAndSet(Node,
                null))
            Node.prev = AVAILABLE;

    }

    public void printQueue() {
        Node Node = myNode.get();

        Node temp = Node;
        String str = "QUEUE: ";
        while (temp.next != null) {
            str += "{" + temp.next.threadname + ": Request " + temp.count + "} -> ";
            temp = temp.next;
        }
        if (str.length() > 7) {
            str = str.substring(0, str.length() - 4);
            System.out.println(str);
        }
    }

    public void lockInterruptibly() {

    }

    public boolean tryLock(long time, TimeUnit unit) {
        return false;
    }

    public Condition newCondition() {
        return null;
    }

}

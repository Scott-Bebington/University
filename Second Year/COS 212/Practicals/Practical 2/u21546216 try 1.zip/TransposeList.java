public class TransposeList<T extends Comparable<T>> extends SelfOrderingList<T> 
{
    @Override
    public SelfOrderingList<T> getBlankList() 
    {
        return new TransposeList<T>();
    }

    @Override
    public void access(T data) 
    {
        // If data is head node
        if (head.data.compareTo(data) == 0)
        {
            return;
        }

        // if data is next to the head
        Node<T> ptr = null;
        if (head.next != null && head.next.data.compareTo(data) == 0)
        {
            ptr = head.next;
            if (ptr.next == null)
            {
                head.prev = ptr;
                head.next = null;
                ptr.prev = null;
                ptr.next = head;
                head = ptr; 
                return;
            }
            // System.out.println(ptr);
            ptr.prev.next = ptr.next;
            ptr.next.prev = ptr.prev;
            ptr.next = null;
            ptr.prev = null;
            ptr.next = head;
            head.prev = ptr;
            head = ptr;
            return;
        }
        ptr = head;
        Node<T> prevptr = null;
        while (ptr.next != null)
        {
            if (ptr.data.compareTo(data) == 0)
            {
                // System.out.println(ptr.prev);
                prevptr = ptr.prev;
                ptr.prev.next = ptr.next;
                ptr.next.prev = ptr.prev;
                ptr.next = null;
                ptr.prev = null;
                // System.out.println(ptr);
                ptr.next = prevptr;
                ptr.prev = prevptr.prev;
                prevptr.prev.next = ptr;
                prevptr.prev = ptr;
                return;
            }
            ptr = ptr.next;
        }
        // System.out.println(ptr);
        prevptr = ptr.prev;
        ptr.prev.next = null;
        
        ptr.next = prevptr;
        ptr.prev = prevptr.prev;

        prevptr.prev.next = ptr;
        prevptr.prev = ptr;
        return;
    }
}

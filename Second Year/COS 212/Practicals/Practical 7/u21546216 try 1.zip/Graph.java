public class Graph {
    public Vertex[] vertices = new Vertex[0];
    public Edge[] edges = new Edge[0];

    public void addVertex(String v) 
    {
        Vertex newVertex = new Vertex(v);
    
        if (vertices.length == 0) 
        {
            vertices = new Vertex[1];
            vertices[0] = newVertex;
            return;
        }
    
        for (int i = 0; i < vertices.length; i++) 
        {
            if (vertices[i].compareTo(newVertex) == 0) 
            {
                return;
            }
        }
    
        Vertex[] temp = new Vertex[vertices.length + 1];
        int count1 = 0;
        while (count1 < vertices.length && vertices[count1].compareTo(newVertex) < 0) 
        {
            count1++;
        }
    
        for (int i = 0; i < count1; i++) 
        {
            temp[i] = vertices[i];
        }
        temp[count1] = newVertex;
        for (int i = count1; i < vertices.length; i++) 
        {
            temp[i + 1] = vertices[i];
        }
    
        vertices = temp; // Update the vertices array with the sorted array

    }
    

    public void removeVertex(String v) 
    {
        Vertex compare = new Vertex(v);
        if(getIndexOf(compare) == -1 || vertices.length == 0 || v == null || v == "")
        {
            return;
        }
        if(vertices.length == 1)
        {
            vertices = new Vertex[0];
            return;
        }
        int count = -1, count2 = 0;
        Vertex[] temp = new Vertex[vertices.length - 1];
        for (int i = 0; i < vertices.length; i++) 
        {
            if (vertices[i].compareTo(compare) == 0) 
            {
                count = i;
                break;
            }
        }

        if(count == -1)
        {
            return;
        }

        for (int i = 0; i < vertices.length; i++) 
        {
            temp[count2] = vertices[i];
            if (i != count) 
            {
                count2++;
            }
        }

        vertices = new Vertex[temp.length];
        for (int i = 0; i < vertices.length; i++) 
        {
            vertices[i] = temp[i];
        }
    }

    public void addEdge(String a, String b, int w) 
    {
        Vertex VertexA = new Vertex(a);
        Vertex VertexB = new Vertex(b);

        if(getIndexOf(VertexA) == -1 || getIndexOf(VertexB) == -1 
        || a == null || a == "" || b == null || b == "" || w < 0)
        {
            return;
        }
    
        Edge newEdge = new Edge(VertexA, VertexB, w);
        if (vertices.length == 0) 
        {
            edges = new Edge[1];
            edges[0] = newEdge;
            return;
        }
    
        for (int i = 0; i < edges.length; i++) 
        {
            if (edges[i].compareTo(newEdge) == 0) 
            {
                return;
            }
        }
    
        Edge[] temp = new Edge[edges.length + 1];
        int count1 = 0;
        while (count1 < edges.length && edges[count1].compareTo(newEdge) < 0) 
        {
            count1++;
        }
    
        for (int i = 0; i < count1; i++) 
        {
            temp[i] = edges[i];
        }
        temp[count1] = newEdge;
        for (int i = count1; i < edges.length; i++) 
        {
            temp[i + 1] = edges[i];
        }
    
        edges = temp; // Update the vertices array with the sorted array
        
    }

    public void removeEdge(String a, String b) 
    {
        if(a == null || a == "" || b == null || b == "")
        {
            return;
        }
        Vertex VertexA = new Vertex(a);
        Vertex VertexB = new Vertex(b);
        if(getIndexOf(VertexA) == -1 || getIndexOf(VertexB) == -1 || edges.length == 0)
        {
            return;
        }
        
        if(edges.length == 1)
        {
            edges = new Edge[0];
            return;
        }
        Edge compare = new Edge(VertexA, VertexB, 0);
        int count = -1, count2 = 0;
        Edge[] temp = new Edge[edges.length - 1];
        for (int i = 0; i < edges.length; i++) 
        {
            if (edges[i].compareTo(compare) == 0) 
            {
                count = i;
                break;
            }
        }

        if(count == -1)
        {
            return;
        }

        for (int i = 0; i < edges.length - 1; i++) 
        {
            temp[count2] = edges[i];
            if (i != count) 
            {
                count2++;
            }
        }
        // temp[count2-2] = edges[edges.length - 1];

        edges = new Edge[edges.length - 1];
        for (int i = 0; i < edges.length; i++) 
        {
            edges[i] = temp[i];
        }
    }

    public int[][] unionFind() 
    {
        int[] root = new int[vertices.length];
        int[] next = new int[vertices.length];
        int[] length = new int[vertices.length];
        int[] result = new int[vertices.length];

        for (int i = 0; i < vertices.length; i++) 
        {
            root[i] = i;
            next[i] = i;
            length[i] = 1;
        }
        
        for (Edge edge : edges) 
        {
            int v = getIndexOf(edge.vertexA);
            int u = getIndexOf(edge.vertexB);
        
            if (root[u] == root[v]) 
            {
                // A cycle was found.
                // DO NOT RETURN
                for (int i = 0; i < result.length; i++) 
                {
                    result[i] = 1;
                }
            } 
            else if (length[root[v]] < length[root[u]]) 
            {
                int rt = root[v];
                length[root[u]] += length[rt];
                root[rt] = root[u];
                for (int j = next[rt]; j != rt; j = next[j]) 
                {
                    root[j] = root[u];
                }
                int temp = next[rt];
                next[rt] = next[root[u]];
                next[root[u]] = temp;
            } 
            else 
            {
                // The same as the else if part, but with u and v reversed
                int rt = root[u];
                length[root[v]] += length[rt];
                root[rt] = root[v];
                for (int j = next[rt]; j != rt; j = next[j]) {
                    root[j] = root[v];
                }
                int temp = next[rt];
                next[rt] = next[root[v]];
                next[root[v]] = temp;
            }
        }

        int[][] finalresult = new int[4][vertices.length];
        finalresult[0] = root;
        finalresult[1] = next;
        finalresult[2] = length;
        finalresult[3] = result;

        return finalresult;
    }

    public boolean cycle() 
    {
        int[] root = new int[vertices.length];
        int[] next = new int[vertices.length];
        int[] length = new int[vertices.length];

        for (int i = 0; i < vertices.length; i++) 
        {
            root[i] = i;
            next[i] = i;
            length[i] = 1;
        }
        
        for (Edge edge : edges) 
        {
            int v = getIndexOf(edge.vertexA);
            int u = getIndexOf(edge.vertexB);
        
            if (root[u] == root[v]) 
            {
                // A cycle was found.
                // DO NOT RETURN
                return true;
            } 
            else if (length[root[v]] < length[root[u]]) 
            {
                int rt = root[v];
                length[root[u]] += length[rt];
                root[rt] = root[u];
                for (int j = next[rt]; j != rt; j = next[j]) 
                {
                    root[j] = root[u];
                }
                int temp = next[rt];
                next[rt] = next[root[u]];
                next[root[u]] = temp;
            } 
            else 
            {
                // The same as the else if part, but with u and v reversed
                int rt = root[u];
                length[root[v]] += length[rt];
                root[rt] = root[v];
                for (int j = next[rt]; j != rt; j = next[j]) {
                    root[j] = root[v];
                }
                int temp = next[rt];
                next[rt] = next[root[v]];
                next[root[v]] = temp;
            }
        }
        return false;
    }

    public Graph minSpanningTree() 
    {
        Graph mst = new Graph();
        Edge[] sortedEdges = sortEdges();
        int[] parent = new int[vertices.length];
        int[] rank = new int[vertices.length];
        for (int i = 0; i < vertices.length; i++) 
        {
            mst.addVertex(vertices[i].name);
            parent[i] = i;
            rank[i] = 0;
        }
        int edgeCount = 0;
        for (int i = 0; i < edges.length && edgeCount < vertices.length - 1; i++) 
        {
            Edge edge = sortedEdges[i];
            int rootA = findRoot(parent, getIndexOf(edge.vertexA));
            int rootB = findRoot(parent, getIndexOf(edge.vertexB));
    
            if (rootA != rootB) 
            {
                mst.addEdge(edge.vertexA.name, edge.vertexB.name, edge.weight);
                // union(parent, rank, rootA, rootB);
                if(rank[rootA] == rank[rootB])
                {
                    parent[rootB] = rootA;
                    rank[rootA]++;
                }
                else if(rank[rootA] > rank[rootB])
                {
                    parent[rootB] = rootA;
                }
                else if(rank[rootA] < rank[rootB])
                {
                    parent[rootA] = rootB;
                }
                edgeCount++;
            }
        }
        return mst;
    }
    
    public Vertex[][] brelazColouring() 
    {
        return new Vertex[0][0];
    }

    @Override
    public String toString() 
    {
        if(vertices.length == 0)
        {
            return "";
        }
        int[][] array = new int[vertices.length][vertices.length];
        for (int i = 0; i < array.length; i++) 
        {
            for (int j = 0; j < array.length; j++) 
            {
                array[i][j] = 0;
            }
        }
        String str = "\t";
        for (int i = 0; i < vertices.length; i++) 
        {
            str += vertices[i].toString() + "\t";
        }
        str += "\n";
        
        for (int i = 0; i < edges.length; i++) 
        {
            int IndexOfA = getIndexOf(edges[i].vertexA);
            int IndexOfB = getIndexOf(edges[i].vertexB);
            array[IndexOfA][IndexOfB] = edges[i].weight;
            array[IndexOfB][IndexOfA] = edges[i].weight;
        }
        for (int i = 0; i < vertices.length; i++) 
        {
            str += vertices[i].toString() + "\t";
            for (int j = 0; j < vertices.length; j++) 
            {
                str += array[i][j] + "\t";
            }
            str += "\n";
        }
        return str;
    }

    // Helper Functions
    public int getIndexOf(Vertex v)
    {
        for(int i = 0; i < vertices.length; i++)
        {
            if(vertices[i].compareTo(v) == 0)
            {
                return i;
            }
        }
        return -1;
    }
    
    private int findRoot(int[] parent, int vertex) 
    {
        if (parent[vertex] != vertex) 
        {
            parent[vertex] = findRoot(parent, parent[vertex]);
        }
        return parent[vertex];
    }
    
    private void union(int[] parent, int[] rank, int rootA, int rootB) 
    {
        if (rank[rootA] < rank[rootB]) 
        {
            parent[rootA] = rootB;
        } 
        else if (rank[rootA] > rank[rootB]) 
        {
            parent[rootB] = rootA;
        } 
        else 
        {
            parent[rootB] = rootA;
            rank[rootA]++;
        }
    }

    private Edge[] sortEdges() 
    {
        Edge[] sortedEdges = new Edge[edges.length];
        for (int i = 0; i < edges.length; i++) 
        {
            sortedEdges[i] = edges[i];
        }
    
        for (int i = 0; i < sortedEdges.length - 1; i++) 
        {
            for (int j = 0; j < sortedEdges.length - i - 1; j++) 
            {
                if (sortedEdges[j].weight > sortedEdges[j + 1].weight) 
                {
                    Edge temp = sortedEdges[j];
                    sortedEdges[j] = sortedEdges[j + 1];
                    sortedEdges[j + 1] = temp;
                }
            }
        }
    
        return sortedEdges;
    }
    
}

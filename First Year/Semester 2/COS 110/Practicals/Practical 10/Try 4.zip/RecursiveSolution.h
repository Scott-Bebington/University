#ifndef RS_H
#define RS_H

#include <stack>

#include "TowersOfHanoi.h"
#include "Disk.h"

template <class T>
class RecursiveSolution : public TowersOfHanoi<T>
{
    void solvegamehelper(int n, int start, int end, int aux);
    public:
        RecursiveSolution(int startTower, int goalTower);
        void solveGame();
        int count();
        bool containsLabel(T label);
};

#endif
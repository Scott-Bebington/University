#ifndef ASSIGNMENT2TEST_ARITHMETIC_CPP
#define ASSIGNMENT2TEST_ARITHMETIC_CPP

#include <iostream>
#include "arithmetic.h"

using namespace std;

Arithmetic::Arithmetic() {}

Arithmetic::Arithmetic(const Arithmetic &rhs) {}

Arithmetic::~Arithmetic() {}

#endif // ASSIGNMENT2TEST_ARITHMETIC_H
